#include "adaptive_mission_mode/app.hpp"
#include <cstdio>
#include <exception>
#include <memory>
#include <rclcpp/rclcpp.hpp>

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  try {
    auto node = std::make_shared<rclcpp::Node>("adaptive_mission_mode");
    adaptive_mission_mode::App app(node);
    rclcpp::spin(node);
  } catch (const std::exception & e) {
    std::fprintf(stderr, "adaptive_mission_mode failed: %s\n", e.what());
  }
  rclcpp::shutdown();
  return 0;
}
