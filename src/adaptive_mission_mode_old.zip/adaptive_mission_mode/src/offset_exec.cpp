#include "adaptive_mission_mode/offset_exec.hpp"
#include <algorithm>
#include <cmath>
#include <utility>
#include <variant>
#include <px4_ros2/mission/mission.hpp>

namespace adaptive_mission_mode
{
namespace
{
constexpr double R = 6371000.0;
constexpr double PI = 3.14159265358979323846;
double rad(double d) {return d * PI / 180.0;}
float dist2d(const Eigen::Vector3d & a, const Eigen::Vector3d & b)
{
  const double la1 = rad(a.x()), la2 = rad(b.x());
  const double dlat = la2 - la1, dlon = rad(b.y() - a.y());
  const double s1 = std::sin(dlat * 0.5), s2 = std::sin(dlon * 0.5);
  const double h = s1 * s1 + std::cos(la1) * std::cos(la2) * s2 * s2;
  return static_cast<float>(2.0 * R * std::atan2(std::sqrt(h), std::sqrt(std::max(0.0, 1.0 - h))));
}
float dist3d(const Eigen::Vector3d & a, const Eigen::Vector3d & b)
{
  const double dz = b.z() - a.z();
  return static_cast<float>(std::hypot(static_cast<double>(dist2d(a, b)), dz));
}
float heading(const Eigen::Vector3d & a, const Eigen::Vector3d & b)
{
  const double la1 = rad(a.x()), la2 = rad(b.x()), dlon = rad(b.y() - a.y());
  const double y = std::sin(dlon) * std::cos(la2);
  const double x = std::cos(la1) * std::sin(la2) - std::sin(la1) * std::cos(la2) * std::cos(dlon);
  return static_cast<float>(std::atan2(y, x));
}
}  // namespace

OffsetExec::OffsetExec(px4_ros2::ModeBase & mode, std::function<float()> off, std::function<bool()> hold)
: node_(mode.node()), off_(std::move(off)), hold_(std::move(hold))
{
  sp_ = std::make_shared<px4_ros2::MulticopterGotoGlobalSetpointType>(mode);
  gps_ = std::make_shared<px4_ros2::OdometryGlobalPosition>(mode);
}

bool OffsetExec::navigationItemTypeSupported(px4_ros2::NavigationItemType t)
{
  return t == px4_ros2::NavigationItemType::Waypoint;
}

bool OffsetExec::frameSupported(px4_ros2::MissionFrame f)
{
  return f == px4_ros2::MissionFrame::Global;
}

void OffsetExec::runTrajectory(const TrajectoryConfig & cfg)
{
  tr_ = cfg; idx_ = cfg.start_index;
}

void OffsetExec::updateSetpoint()
{
  if (!idx_ || (hold_ && hold_())) {return;}
  const auto * nav = std::get_if<px4_ros2::NavigationItem>(&tr_.trajectory->items()[*idx_]);
  if (!nav) {next(); return;}
  if (!gps_->positionValid()) {RCLCPP_ERROR_THROTTLE(node_.get_logger(), *node_.get_clock(), 1000, "No valid global position"); tr_.on_failure(); return;}
  Eigen::Vector3d tgt = std::get<px4_ros2::Waypoint>(nav->data).coordinate;
  tgt.z() += static_cast<double>(off_());
  const Eigen::Vector3d cur = gps_->position();
  std::optional<float> yaw{};
  if (dist2d(cur, tgt) > 0.1F) {yaw = heading(cur, tgt);}
  sp_->update(tgt, yaw, tr_.options.horizontal_velocity, tr_.options.vertical_velocity, tr_.options.max_heading_rate);
  const float acc = (*idx_ == tr_.end_index && tr_.stop_at_last) ? 1.0F : 2.0F;
  if (near(tgt, acc)) {next();}
}

void OffsetExec::next()
{
  const int old = *idx_; idx_ = old + 1;
  if (*idx_ > tr_.end_index) {idx_.reset();}
  tr_.on_index_reached(old);
}

bool OffsetExec::near(const Eigen::Vector3d & p, float r) const
{
  return gps_->positionValid() && dist3d(gps_->position(), p) < r;
}

}  // namespace adaptive_mission_mode
