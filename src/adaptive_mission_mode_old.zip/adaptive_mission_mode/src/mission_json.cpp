#include "adaptive_mission_mode/mission_json.hpp"
#include <algorithm>
#include <cmath>
#include <cctype>
#include <limits>
#include <stdexcept>
#include <string>
#include <px4_ros2/mission/mission.hpp>

namespace adaptive_mission_mode
{
namespace
{
constexpr int NAV_WP = 16, NAV_RTL = 20, NAV_LAND = 21, NAV_TAKEOFF = 22, DO_SPEED = 178;
constexpr int F_GLOBAL = 0, F_REL = 3, F_GLOBAL_INT = 5, F_REL_INT = 6;

bool finite(double v) {return std::isfinite(v);}
std::string low(std::string s) {std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){return char(std::tolower(c));}); return s;}
bool num(const nlohmann::json & j, const char * k) {return j.is_object() && j.contains(k) && j.at(k).is_number();}
bool str(const nlohmann::json & j, const char * k) {return j.is_object() && j.contains(k) && j.at(k).is_string();}
double val(const nlohmann::json & j, const char * k) {return num(j, k) ? j.at(k).get<double>() : std::numeric_limits<double>::quiet_NaN();}
std::string idOf(const nlohmann::json & it, const char * p, int i) {return str(it, "id") ? it.at("id").get<std::string>() : (num(it, "seq") ? std::string(p) + std::to_string(it.at("seq").get<int>()) : std::string(p) + std::to_string(i));}

bool boundary(char c) {return !std::isalnum(static_cast<unsigned char>(c)) && c != '_' && c != '.';}
bool token(const std::string & s, size_t p, const std::string & t)
{
  if (p + t.size() > s.size()) {return false;}
  if ((p && !boundary(s[p - 1])) || (p + t.size() < s.size() && !boundary(s[p + t.size()]))) {return false;}
  for (size_t i = 0; i < t.size(); ++i) {if (std::tolower(static_cast<unsigned char>(s[p + i])) != std::tolower(static_cast<unsigned char>(t[i]))) {return false;}}
  return true;
}

std::string clean(const std::string & s)
{
  std::string o; o.reserve(s.size()); bool in = false, esc = false;
  for (size_t i = 0; i < s.size();) {
    const char c = s[i];
    if (in) {
      o += c;
      if (esc) {esc = false;}
      else if (c == '\\') {esc = true;}
      else if (c == '"') {in = false;}
      ++i; continue;
    }
    if (c == '"') {in = true; o += c; ++i; continue;}
    if (token(s, i, "nan")) {o += "null"; i += 3; continue;}
    if (i + 1 < s.size() && s[i] == '-' && token(s, i + 1, "infinity")) {o += "null"; i += 9; continue;}
    if (token(s, i, "infinity")) {o += "null"; i += 8; continue;}
    o += c; ++i;
  }
  return o;
}

const nlohmann::json * rawItems(const nlohmann::json & j)
{
  if (j.contains("raw_items") && j.at("raw_items").is_array()) {return &j.at("raw_items");}
  if (j.contains("mission") && j.at("mission").is_object() && j.at("mission").contains("raw_items") && j.at("mission").at("raw_items").is_array()) {return &j.at("mission").at("raw_items");}
  return nullptr;
}

const nlohmann::json * normItems(const nlohmann::json & j)
{
  if (j.contains("mission") && j.at("mission").is_object()) {
    const auto & m = j.at("mission");
    if (m.contains("items") && m.at("items").is_array()) {return &m.at("items");}
    if (m.contains("mission_items") && m.at("mission_items").is_array()) {return &m.at("mission_items");}
    if (m.contains("mission") && m.at("mission").is_object()) {
      const auto & n = m.at("mission");
      if (n.contains("items") && n.at("items").is_array()) {return &n.at("items");}
      if (n.contains("mission_items") && n.at("mission_items").is_array()) {return &n.at("mission_items");}
    }
  }
  if (j.contains("mission_items") && j.at("mission_items").is_array()) {return &j.at("mission_items");}
  if (j.contains("items") && j.at("items").is_array()) {return &j.at("items");}
  return nullptr;
}

bool nativeItems(const nlohmann::json & a)
{
  if (!a.is_array()) {return false;}
  for (const auto & it : a) {if (!str(it, "type")) {return false;}}
  return true;
}

nlohmann::json defaults(const nlohmann::json & j)
{
  nlohmann::json d = nlohmann::json::object();
  if (j.contains("mission") && j.at("mission").is_object()) {
    const auto & m = j.at("mission");
    if (m.contains("defaults") && m.at("defaults").is_object()) {d = m.at("defaults");}
    if (m.contains("mission") && m.at("mission").is_object() && m.at("mission").contains("defaults") && m.at("mission").at("defaults").is_object()) {d = m.at("mission").at("defaults");}
  }
  if (!d.contains("horizontalVelocity")) {d["horizontalVelocity"] = num(d, "speed_m_s") ? d.at("speed_m_s").get<double>() : 5.0;}
  if (!d.contains("verticalVelocity")) {d["verticalVelocity"] = 2.0;}
  if (!d.contains("maxHeadingRate")) {d["maxHeadingRate"] = 60.0;}
  return d;
}

double refAlt(const nlohmann::json & j, double cur)
{
  if (num(j, "altitude_reference_msl")) {return j.at("altitude_reference_msl").get<double>();}
  if (num(j, "home_altitude_msl")) {return j.at("home_altitude_msl").get<double>();}
  if (j.contains("home") && num(j.at("home"), "alt_msl")) {return j.at("home").at("alt_msl").get<double>();}
  if (j.contains("target") && num(j.at("target"), "home_altitude_msl")) {return j.at("target").at("home_altitude_msl").get<double>();}
  return cur;
}

int cmdOf(const nlohmann::json & it)
{
  if (num(it, "command")) {return it.at("command").get<int>();}
  if (!str(it, "command")) {return -1;}
  const auto c = low(it.at("command").get<std::string>());
  if (c.find("waypoint") != std::string::npos) {return NAV_WP;}
  if (c.find("takeoff") != std::string::npos) {return NAV_TAKEOFF;}
  if (c.find("land") != std::string::npos) {return NAV_LAND;}
  if (c.find("rtl") != std::string::npos || c.find("return") != std::string::npos) {return NAV_RTL;}
  if (c.find("speed") != std::string::npos) {return DO_SPEED;}
  return -1;
}

bool relFrame(const nlohmann::json & it)
{
  if (num(it, "frame")) {const int f = it.at("frame").get<int>(); return f == F_REL || f == F_REL_INT;}
  if (str(it, "frame")) {return low(it.at("frame").get<std::string>()).find("relative") != std::string::npos;}
  return false;
}

bool globalFrame(const nlohmann::json & it)
{
  if (num(it, "frame")) {const int f = it.at("frame").get<int>(); return f == F_GLOBAL || f == F_GLOBAL_INT || f == F_REL || f == F_REL_INT;}
  if (str(it, "frame")) {return low(it.at("frame").get<std::string>()).find("global") != std::string::npos;}
  return true;
}

double deg(double v, bool lat)
{
  if (!finite(v)) {return v;}
  const double lim = lat ? 90.0 : 180.0;
  return (std::abs(v) > lim && std::abs(v) > 1000.0) ? v * 1e-7 : v;
}

bool posOf(const nlohmann::json & it, double & lat, double & lon)
{
  lat = val(it, "latitude_deg"); lon = val(it, "longitude_deg");
  if (!finite(lat)) {lat = val(it, "lat");} if (!finite(lon)) {lon = val(it, "lon");}
  if (!finite(lat)) {lat = val(it, "x");} if (!finite(lon)) {lon = val(it, "y");}
  lat = deg(lat, true); lon = deg(lon, false);
  return finite(lat) && finite(lon) && std::abs(lat) <= 90.0 && std::abs(lon) <= 180.0;
}

double altOf(const nlohmann::json & it, double ref)
{
  if (num(it, "altitude_msl")) {return it.at("altitude_msl").get<double>();}
  if (num(it, "alt_msl")) {return it.at("alt_msl").get<double>();}
  if (num(it, "absolute_altitude_m")) {return it.at("absolute_altitude_m").get<double>();}
  if (num(it, "relative_altitude_m")) {if (!finite(ref)) {throw std::runtime_error("relative altitude needs valid current/home MSL altitude");} return ref + it.at("relative_altitude_m").get<double>();}
  if (num(it, "z")) {if (!relFrame(it)) {return it.at("z").get<double>();} if (!finite(ref)) {throw std::runtime_error("relative MAVLink frame needs valid current/home MSL altitude");} return ref + it.at("z").get<double>();}
  if (num(it, "altitude")) {return relFrame(it) && finite(ref) ? ref + it.at("altitude").get<double>() : it.at("altitude").get<double>();}
  if (!finite(ref)) {throw std::runtime_error("mission item has no altitude and no valid altitude reference");}
  return ref;
}

nlohmann::json wp(const nlohmann::json & it, int i, double lat, double lon, double alt)
{
  return {{"type", "navigation"}, {"navigationType", "waypoint"}, {"frame", "global"}, {"id", idOf(it, "fc_wp_", i)}, {"x", lat}, {"y", lon}, {"z", alt}};
}

void skip(nlohmann::json & s, const nlohmann::json & it, int i, int cmd, const std::string & why)
{
  nlohmann::json o{{"index", i}, {"id", idOf(it, "fc_skip_", i)}, {"reason", why}};
  if (cmd >= 0) {o["command"] = cmd;} if (str(it, "command_name")) {o["command_name"] = it.at("command_name");}
  s.push_back(o);
}

bool addItem(nlohmann::json & out, const nlohmann::json & it, int i, double ref)
{
  auto & items = out["mission"]["items"]; auto & skips = out["skipped_source_items"];
  const int cmd = cmdOf(it); const std::string type = str(it, "type") ? low(it.at("type").get<std::string>()) : "";
  if (cmd == DO_SPEED) {skip(skips, it, i, cmd, "do_change_speed_kept_as_mavlink_metadata_not_flight_item"); return false;}
  if (cmd == NAV_RTL || type == "rtl") {items.push_back({{"type", "rtl"}, {"id", idOf(it, "fc_rtl_", i)}}); return true;}
  if (cmd == NAV_TAKEOFF || type == "takeoff") {items.push_back({{"type", "takeoff"}, {"id", idOf(it, "fc_takeoff_", i)}, {"altitude", altOf(it, ref)}}); return true;}
  if (cmd == NAV_LAND || type == "land") {double la, lo; if (posOf(it, la, lo) && globalFrame(it)) {items.push_back(wp(it, i, la, lo, altOf(it, ref)));} items.push_back({{"type", "land"}, {"id", idOf(it, "fc_land_", i)}}); return true;}
  if (cmd == NAV_WP || type == "navigation" || cmd < 0) {double la, lo; if (posOf(it, la, lo) && globalFrame(it)) {items.push_back(wp(it, i, la, lo, altOf(it, ref))); return true;}}
  skip(skips, it, i, cmd, "non_navigation_mavlink_action_skipped"); return false;
}


PlanInfo finishPlan(nlohmann::json & out, int src_count)
{
  bool pre = false; std::optional<double> tk_alt;
  auto & items = out["mission"]["items"];
  if (items.is_array() && !items.empty() && items.front().value("type", "") == "takeoff") {
    pre = true;
    const auto & tk = items.front();
    if (num(tk, "altitude")) {tk_alt = tk.at("altitude").get<double>();}
    items.erase(items.begin());
  }
  out["pre_takeoff"] = pre;
  out["pre_takeoff_alt_msl"] = tk_alt ? nlohmann::json(*tk_alt) : nlohmann::json(nullptr);
  out["executable_item_count"] = items.size();
  out["skipped_item_count"] = out["skipped_source_items"].size();
  if (items.empty()) {throw std::runtime_error("mission has no executable waypoint/land/rtl item after pre-takeoff");}
  const px4_ros2::Mission m(out);
  return {out, m.checksum(), src_count, static_cast<int>(items.size()), static_cast<int>(out["skipped_source_items"].size()), pre, tk_alt};
}
}  // namespace


std::string missionKey(const std::string & text)
{
  try {
    const auto j = nlohmann::json::parse(clean(text));
    nlohmann::json k;
    if (j.contains("source")) {k["source"] = j.at("source");}
    if (j.contains("remote_opaque_id")) {k["remote_opaque_id"] = j.at("remote_opaque_id");}
    if (j.contains("hash")) {k["hash"] = j.at("hash");}
    if (j.contains("item_count")) {k["item_count"] = j.at("item_count");}
    if (j.contains("downloaded_items")) {k["downloaded_items"] = j.at("downloaded_items");}
    const auto * raw = rawItems(j);
    if (raw) {
      k["raw_count"] = raw->size();
      k["raw_items"] = nlohmann::json::array();
      for (const auto & it : *raw) {
        nlohmann::json r;
        for (const auto * name : {"seq", "frame", "command", "mission_type", "current", "autocontinue", "param1", "param2", "param3", "param4", "x", "y", "z"}) {
          if (it.contains(name)) {r[name] = it.at(name);}
        }
        k["raw_items"].push_back(r);
      }
      return k.dump();
    }
    const auto * items = normItems(j);
    if (items) {k["items"] = *items; return k.dump();}
    return j.dump();
  } catch (...) {
    return clean(text);
  }
}

PlanInfo parsePlan(const std::string & text, double cur_alt_msl)
{
  const auto in = nlohmann::json::parse(clean(text));
  if (const auto * raw = rawItems(in)) {
    const double ref = refAlt(in, cur_alt_msl);
    nlohmann::json out; out["version"] = in.value("version", 1);
    out["source_format"] = "mavlink_mission_protocol_raw_items";
    out["source_item_count"] = num(in, "item_count") ? in.at("item_count") : nlohmann::json(raw->size());
    out["remote_opaque_id"] = in.contains("remote_opaque_id") ? in.at("remote_opaque_id") : nlohmann::json(nullptr);
    out["source_hash"] = in.contains("hash") ? in.at("hash") : nlohmann::json(nullptr);
    out["altitude_reference_msl"] = finite(ref) ? nlohmann::json(ref) : nlohmann::json(nullptr);
    if (in.contains("target")) {out["target_system"] = in.at("target");}
    out["mission"]["defaults"] = defaults(in); out["mission"]["items"] = nlohmann::json::array(); out["skipped_source_items"] = nlohmann::json::array();
    for (int i = 0; i < static_cast<int>(raw->size()); ++i) {addItem(out, raw->at(i), i, ref);}
    return finishPlan(out, static_cast<int>(raw->size()));
  }
  const auto * items = normItems(in);
  if (!items || !items->is_array()) {throw std::runtime_error("mission JSON needs raw_items or mission(.mission).items");}
  const bool direct_native = in.contains("mission") && in.at("mission").is_object() && in.at("mission").contains("items") && in.at("mission").at("items").is_array() && nativeItems(in.at("mission").at("items"));
  if (direct_native) {auto out = in; if (!out.contains("skipped_source_items")) {out["skipped_source_items"] = nlohmann::json::array();} return finishPlan(out, static_cast<int>(out.at("mission").at("items").size()));}
  const double ref = refAlt(in, cur_alt_msl); nlohmann::json out; out["version"] = 1; out["source_format"] = "normalized_mission_items"; out["mission"]["defaults"] = defaults(in); out["mission"]["items"] = nlohmann::json::array(); out["skipped_source_items"] = nlohmann::json::array();
  for (int i = 0; i < static_cast<int>(items->size()); ++i) {addItem(out, items->at(i), i, ref);}
  out["source_item_count"] = items->size(); out["altitude_reference_msl"] = finite(ref) ? nlohmann::json(ref) : nlohmann::json(nullptr);
  return finishPlan(out, static_cast<int>(items->size()));
}

}  // namespace adaptive_mission_mode
