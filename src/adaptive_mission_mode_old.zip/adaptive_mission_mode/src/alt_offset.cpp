#include "adaptive_mission_mode/alt_offset.hpp"
#include <algorithm>

namespace adaptive_mission_mode
{

void AltOffset::reset()
{
  m_ = 0.0F; rate_ = 0.0F; active_ = false; last_ = {};
}

void AltOffset::tick(float stick, bool on, std::chrono::steady_clock::time_point now)
{
  if (last_ == std::chrono::steady_clock::time_point{}) {last_ = now;}
  const float dt = std::clamp(std::chrono::duration<float>(now - last_).count(), 0.0F, 0.5F);
  last_ = now; rate_ = 0.0F; active_ = false;
  if (!on) {return;}
  const float s = std::clamp(stick, -1.0F, 1.0F);
  if (s <= dead_) {return;}
  const float k = (s - dead_) / std::max(1.0F - dead_, 0.01F);
  rate_ = std::clamp(k, 0.0F, 1.0F) * max_rate_;
  m_ = std::clamp(m_ + rate_ * dt, 0.0F, lim_);
  active_ = true;
}

}  // namespace adaptive_mission_mode
