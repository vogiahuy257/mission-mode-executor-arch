#include "adaptive_mission_mode/app.hpp"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <limits>
#include <utility>
#include <px4_ros2/mission/mission.hpp>
#include <px4_ros2/utils/message_version.hpp>
#include "adaptive_mission_mode/offset_exec.hpp"

using namespace std::chrono_literals;

namespace adaptive_mission_mode
{
namespace
{
constexpr char MODE_NAME[] = "Adaptive Mission Mode";
constexpr char DEF_MISSION_TOPIC[] = "~/mission_json";
constexpr char DEF_FC_TOPIC[] = "/fc_mission_reader/mission_json";

px4_ros2::MissionExecutor::Configuration cfg(std::function<float()> off, std::function<bool()> hold)
{
  px4_ros2::MissionExecutor::Configuration c;
  c.default_actions = {"rtl", "land", "takeoff", "onFailure", "hold", "changeSettings"};
  c.trajectory_executor_factory = [off, hold](px4_ros2::ModeBase & m) {return std::make_shared<OffsetExec>(m, off, hold);};
  return c;
}
}  // namespace

Exec::Exec(rclcpp::Node & node, std::function<float()> off, std::function<bool()> hold)
: px4_ros2::MissionExecutor(MODE_NAME, cfg(std::move(off), std::move(hold)), node) {}

App::App(std::shared_ptr<rclcpp::Node> node) : node_(std::move(node))
{
  mission_topic_ = node_->declare_parameter<std::string>("mission_topic", DEF_MISSION_TOPIC);
  fc_topic_ = node_->declare_parameter<std::string>("fc_mission_topic", DEF_FC_TOPIC);
  allow_start_ = node_->declare_parameter<bool>("allow_activate_topic_start", false);
  auto_arm_ = node_->declare_parameter<bool>("auto_arm_on_activate", true);
  auto_takeoff_ = node_->declare_parameter<bool>("auto_takeoff_on_activate", true);
  pub_items_ = node_->declare_parameter<bool>("publish_full_item_list", false);
  takeoff_tol_m_ = node_->declare_parameter<double>("takeoff_acceptance_m", 0.7);
  target_sys_ = node_->declare_parameter<int>("target_system", 1);
  target_comp_ = node_->declare_parameter<int>("target_component", 1);
  source_sys_ = node_->declare_parameter<int>("source_system", 1);
  source_comp_ = node_->declare_parameter<int>("source_component", 1);
  exec_ = std::make_unique<Exec>(*node_, [this]() {return off_.m();}, [this]() {return pre_active_;});
  stick_ = std::make_unique<px4_ros2::ManualControlInput>(exec_->base().ownedMode(), true);
  gps_ = std::make_unique<px4_ros2::OdometryGlobalPosition>(exec_->base().ownedMode());
  exec_->onReadynessUpdate([this](bool ok, const std::vector<std::string> & err) {ready_ = ok; if (!ok) {for (const auto & e : err) {RCLCPP_WARN(node_->get_logger(), "Mission not ready: %s", e.c_str());}} pubState();});
  exec_->onActivated([this]() {
    active_ = true; off_.reset();
    if (!loaded_ || !ready_) {state_ = "reject_no_mission"; RCLCPP_ERROR(node_->get_logger(), "Adaptive mode active but mission is not ready"); posctl(); pubState(); return;}
    if (auto_takeoff_ && needTakeoff()) {beginPre("mode activated on ground"); return;}
    pre_active_ = false; state_ = "mission"; pubState();
  });
  exec_->onDeactivated([this]() {active_ = false; cur_ = -1; if (resume_pending_) {state_ = "pause_rtl";} else if (!pre_active_) {state_ = "idle"; off_.reset();} pubState();});
  exec_->onProgressUpdate([this](int i) {cur_ = i; pubState();});
  exec_->onCompleted([this]() {active_ = false; resume_pending_ = false; resume_json_ = nlohmann::json::object(); resume_info_ = nlohmann::json::object(); state_ = "done"; cur_ = -1; off_.reset(); pubState();});
  bind();
  reg_timer_ = node_->create_wall_timer(1s, [this]() {reg();});
  alt_timer_ = node_->create_wall_timer(50ms, [this]() {altTick();});
  state_timer_ = node_->create_wall_timer(1s, [this]() {pubState();});
  retry_timer_ = node_->create_wall_timer(500ms, [this]() {retryPending();});
  pre_timer_ = node_->create_wall_timer(200ms, [this]() {preTick();});
  RCLCPP_INFO(node_->get_logger(), "Ready. Load mission from %s or %s, then switch PX4 to Adaptive Mission Mode. It can auto arm/takeoff first.", mission_topic_.c_str(), fc_topic_.c_str());
}

void App::bind()
{
  state_pub_ = node_->create_publisher<std_msgs::msg::String>("~/state", rclcpp::QoS(1).reliable());
  cmd_pub_ = node_->create_publisher<px4_msgs::msg::VehicleCommand>("fmu/in/vehicle_command" + px4_ros2::getMessageNameVersion<px4_msgs::msg::VehicleCommand>(), rclcpp::QoS(1));
  status_sub_ = node_->create_subscription<px4_msgs::msg::VehicleStatus>("fmu/out/vehicle_status" + px4_ros2::getMessageNameVersion<px4_msgs::msg::VehicleStatus>(), rclcpp::QoS(1).best_effort(), [this](px4_msgs::msg::VehicleStatus::SharedPtr m) {if (m) {status(*m);}});
  ack_sub_ = node_->create_subscription<px4_msgs::msg::VehicleCommandAck>("fmu/out/vehicle_command_ack" + px4_ros2::getMessageNameVersion<px4_msgs::msg::VehicleCommandAck>(), rclcpp::QoS(10).best_effort(), [this](px4_msgs::msg::VehicleCommandAck::SharedPtr m) {if (m) {ack(*m);}});
  mission_sub_ = node_->create_subscription<std_msgs::msg::String>(mission_topic_, rclcpp::QoS(1).reliable(), [this](std_msgs::msg::String::SharedPtr m) {if (m) {load(m->data);}});
  if (fc_topic_ != mission_topic_) {fc_sub_ = node_->create_subscription<std_msgs::msg::String>(fc_topic_, rclcpp::QoS(1).reliable(), [this](std_msgs::msg::String::SharedPtr m) {if (m) {load(m->data);}});}
  act_sub_ = node_->create_subscription<std_msgs::msg::Bool>("~/activate", rclcpp::QoS(1).reliable(), [this](std_msgs::msg::Bool::SharedPtr m) {if (m) {start(m->data);}});
  pause_sub_ = node_->create_subscription<std_msgs::msg::Bool>("~/pause_rtl", rclcpp::QoS(1).reliable(), [this](std_msgs::msg::Bool::SharedPtr m) {if (m && m->data) {pauseRtl();}});
  cont_sub_ = node_->create_subscription<std_msgs::msg::Bool>("~/continue_mission", rclcpp::QoS(1).reliable(), [this](std_msgs::msg::Bool::SharedPtr m) {if (m && m->data) {continueMission();}});
}

bool App::fmu() const
{
  return node_->count_publishers("fmu/out/vehicle_status" + px4_ros2::getMessageNameVersion<px4_msgs::msg::VehicleStatus>()) > 0;
}

void App::reg()
{
  if (reg_ok_) {return;}
  const auto now = node_->now();
  const bool log = last_reg_log_.nanoseconds() == 0 || (now - last_reg_log_).seconds() > 3.0;
  if (!fmu()) {if (log) {last_reg_log_ = now; RCLCPP_WARN(node_->get_logger(), "Waiting FMU DDS before registering custom mode");} return;}
  if (last_reg_try_.nanoseconds() != 0 && (now - last_reg_try_).seconds() < 5.0) {return;}
  last_reg_try_ = now; RCLCPP_INFO(node_->get_logger(), "Registering Adaptive Mission Mode...");
  reg_ok_ = exec_->doRegister();
  if (reg_ok_) {reg_timer_->cancel(); RCLCPP_INFO(node_->get_logger(), "Adaptive Mission Mode registered");}
  else {RCLCPP_ERROR(node_->get_logger(), "Register failed. Check PX4/px4_msgs/px4_ros2_cpp version match.");}
}

void App::load(const std::string & text)
{
  if (active_) {RCLCPP_ERROR(node_->get_logger(), "Reject mission reload while active"); return;}
  if (resume_pending_) {RCLCPP_WARN_THROTTLE(node_->get_logger(), *node_->get_clock(), 3000, "Ignore mission reload while pause_rtl resume point is pending"); return;}
  const auto key = missionKey(text);
  if (loaded_ && key == src_key_) {return;}
  try {
    plan_ = parsePlan(text, altMsl());
    exec_->setMission(px4_ros2::Mission(plan_.json));
    src_key_ = key; pending_ = false; pending_text_.clear(); pending_key_.clear();
    loaded_ = true; cur_ = -1; state_ = "idle"; off_.reset();
    RCLCPP_INFO(node_->get_logger(), "Loaded mission: src=%d exec=%d skip=%d hash=%s", plan_.src_count, plan_.exec_count, plan_.skip_count, plan_.hash.c_str());
  } catch (const std::exception & e) {
    const std::string err = e.what();
    if (!std::isfinite(altMsl()) && err.find("altitude") != std::string::npos) {
      pending_ = true; pending_text_ = text; pending_key_ = key; state_ = "waiting_alt_ref";
      RCLCPP_WARN(node_->get_logger(), "Mission waits for valid global/home MSL altitude: %s", e.what()); pubState(); return;
    }
    loaded_ = false; state_ = "mission_rejected"; RCLCPP_ERROR(node_->get_logger(), "Mission rejected: %s", e.what());
  }
  pubState();
}

void App::retryPending()
{
  if (!pending_ || active_) {return;}
  if (!std::isfinite(altMsl())) {return;}
  const auto text = pending_text_;
  pending_ = false; pending_text_.clear(); pending_key_.clear();
  load(text);
}

void App::start(bool on)
{
  if (!on) {stop(); return;}
  if (!allow_start_) {RCLCPP_WARN(node_->get_logger(), "activate=true ignored. Switch PX4 to Adaptive Mission Mode to start."); return;}
  if (!loaded_ || !ready_) {RCLCPP_ERROR(node_->get_logger(), "Cannot start: mission not ready"); return;}
  arm(); setMode(static_cast<float>(exec_->id())); state_ = "start_request"; pubState();
}

void App::stop()
{
  if (exec_) {exec_->abort();}
  active_ = false; resume_pending_ = false; resume_json_ = nlohmann::json::object(); resume_info_ = nlohmann::json::object(); cur_ = -1; state_ = "idle"; off_.reset(); pubState();
}

bool App::saveResume()
{
  if (!loaded_ || !plan_.json.contains("mission") || !plan_.json.at("mission").contains("items")) {RCLCPP_ERROR(node_->get_logger(), "Cannot pause RTL: no mission to resume"); return false;}
  if (!gps_ || !gps_->positionValid()) {RCLCPP_ERROR(node_->get_logger(), "Cannot pause RTL: no valid global position"); return false;}
  const auto pos = gps_->position();
  const int n = static_cast<int>(plan_.json.at("mission").at("items").size());
  resume_index_ = std::clamp(cur_ + 1, 0, n);
  resume_offset_ = off_.m();
  nlohmann::json out = plan_.json;
  auto new_items = nlohmann::json::array();
  new_items.push_back({{"type", "navigation"}, {"navigationType", "waypoint"}, {"frame", "global"}, {"id", "pause_rtl_resume_point"}, {"x", pos.x()}, {"y", pos.y()}, {"z", pos.z()}});
  const auto & old_items = plan_.json.at("mission").at("items");
  for (int i = resume_index_; i < n; ++i) {
    auto it = old_items.at(i);
    if (resume_offset_ != 0.0F) {
      if (it.value("type", "") == "navigation" && it.contains("z") && it.at("z").is_number()) {it["z"] = it.at("z").get<double>() + static_cast<double>(resume_offset_);}
      if (it.contains("altitude") && it.at("altitude").is_number()) {it["altitude"] = it.at("altitude").get<double>() + static_cast<double>(resume_offset_);}
    }
    new_items.push_back(it);
  }
  out["mission"]["items"] = new_items;
  out["source_format"] = "adaptive_pause_rtl_resume";
  out["pre_takeoff"] = true;
  out["pre_takeoff_alt_msl"] = pos.z();
  out["executable_item_count"] = new_items.size();
  out["resume"] = {{"enabled", true}, {"resume_index", resume_index_}, {"original_current_index", cur_}, {"saved_altitude_offset_m", resume_offset_}, {"return_point", {{"lat", pos.x()}, {"lon", pos.y()}, {"alt_msl", pos.z()}}}};
  resume_json_ = out; resume_info_ = out["resume"]; resume_pending_ = true;
  RCLCPP_WARN(node_->get_logger(), "Pause RTL saved resume point lat=%.7f lon=%.7f alt=%.2f m, next mission index=%d, baked offset=%.2f m", pos.x(), pos.y(), pos.z(), resume_index_, resume_offset_);
  return true;
}

bool App::applyResume()
{
  if (!resume_pending_) {return false;}
  try {
    px4_ros2::Mission m(resume_json_);
    exec_->setMission(m);
    plan_.json = resume_json_; plan_.hash = m.checksum(); plan_.src_count = resume_index_; plan_.exec_count = static_cast<int>(resume_json_.at("mission").at("items").size()); plan_.skip_count = 0; plan_.pre_takeoff = true; plan_.takeoff_alt_msl = resume_json_.at("pre_takeoff_alt_msl").get<double>();
    resume_pending_ = false; off_.reset(); cur_ = -1; loaded_ = true; state_ = "continue_request";
    RCLCPP_WARN(node_->get_logger(), "Continue mission loaded resume route: takeoff if needed, return to pause point, then continue with %d remaining items", plan_.exec_count - 1);
    return true;
  } catch (const std::exception & e) {
    RCLCPP_ERROR(node_->get_logger(), "Cannot apply resume mission: %s", e.what());
    return false;
  }
}

void App::pauseRtl()
{
  if (!saveResume()) {return;}
  state_ = "pause_rtl";
  rtl();
  pubState();
}

void App::continueMission()
{
  if (resume_pending_) {if (!applyResume()) {pubState(); return;}}
  if (!loaded_) {RCLCPP_ERROR(node_->get_logger(), "Cannot continue: no mission loaded"); pubState(); return;}
  setMode(static_cast<float>(exec_->id()));
  state_ = "continue_request";
  pubState();
}

nlohmann::json App::resumeState() const
{
  if (!resume_pending_) {return {{"pending", false}};}
  auto r = resume_info_; r["pending"] = true; return r;
}

void App::status(const px4_msgs::msg::VehicleStatus & m)
{
  nav_ = m.nav_state; user_intent_ = m.nav_state_user_intention; arm_state_ = m.arming_state; executor_ = m.executor_in_charge; failsafe_ = m.failsafe;
  armed_ = m.arming_state == px4_msgs::msg::VehicleStatus::ARMING_STATE_ARMED;
  reg();
  const auto mode_id = exec_ ? static_cast<uint8_t>(exec_->id()) : uint8_t{};
  const bool in_charge = reg_ok_ && exec_ && executor_ == mode_id;
  const bool user_selected = reg_ok_ && exec_ && (user_intent_ == mode_id || nav_ == mode_id);
  if (user_selected && !active_ && !pre_active_ && loaded_ && ready_ && auto_takeoff_ && (needTakeoff() || (auto_arm_ && !armed_))) {beginPre("selected by user intention before activation");}
  if (user_selected && !active_ && !pre_active_) {
    const auto now = node_->now();
    if (last_select_watch_log_.nanoseconds() == 0 || (now - last_select_watch_log_).seconds() > 2.0) {last_select_watch_log_ = now; RCLCPP_WARN(node_->get_logger(), "Adaptive selected but executor is not active yet: armed=%d nav_state=%u user_intention=%u executor=%u mode_id=%u", armed_ ? 1 : 0, nav_, user_intent_, executor_, mode_id);}
  }
  (void)in_charge;
}

void App::ack(const px4_msgs::msg::VehicleCommandAck & m)
{
  const bool mine = m.command == px4_msgs::msg::VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM || m.command == px4_msgs::msg::VehicleCommand::VEHICLE_CMD_NAV_TAKEOFF || m.command == px4_msgs::msg::VehicleCommand::VEHICLE_CMD_SET_NAV_STATE;
  if (!mine) {return;}
  const char * level = m.result == 0 ? "ACK" : "NACK";
  if (m.result == 0) {RCLCPP_INFO(node_->get_logger(), "%s command=%u result=%u", level, m.command, m.result);}
  else {RCLCPP_ERROR(node_->get_logger(), "%s command=%u result=%u", level, m.command, m.result);}
}

void App::beginPre(const char * reason)
{
  pre_active_ = true; pre_takeoff_sent_ = false; pre_mode_sent_ = false; state_ = "pre_takeoff"; cur_ = -1;
  last_arm_cmd_ = rclcpp::Time{}; last_takeoff_cmd_ = rclcpp::Time{}; last_mode_cmd_ = rclcpp::Time{};
  RCLCPP_WARN(node_->get_logger(), "Adaptive %s: auto ARM + MAV_CMD_NAV_TAKEOFF first", reason); pubState();
}

void App::altTick()
{
  const bool ok = active_ && armed_ && stick_ && stick_->isValid();
  const float old = off_.m(); off_.tick(ok ? stick_->throttle() : 0.0F, ok, std::chrono::steady_clock::now());
  const auto now = node_->now();
  if ((off_.active() || old != off_.m()) && (last_alt_log_.nanoseconds() == 0 || (now - last_alt_log_).seconds() > 1.0)) {last_alt_log_ = now; RCLCPP_INFO(node_->get_logger(), "Altitude offset %.2f m, rate %.2f m/s", off_.m(), off_.rate());}
}

void App::preTick()
{
  if (!pre_active_ || !loaded_ || !ready_) {return;}
  const auto now = node_->now();
  if (auto_arm_ && !armed_) {
    if (last_arm_cmd_.nanoseconds() == 0 || (now - last_arm_cmd_).seconds() > 1.0) {last_arm_cmd_ = now; state_ = "arming"; RCLCPP_WARN(node_->get_logger(), "Sending arm before MAV takeoff"); arm(); pubState();}
    return;
  }
  const double target = takeoffAlt(); const double cur = altMsl();
  if (!std::isfinite(target)) {RCLCPP_ERROR(node_->get_logger(), "Pre-takeoff failed: no valid takeoff altitude MSL"); pre_active_ = false; state_ = "idle"; pubState(); return;}
  if (std::isfinite(cur) && cur >= target - takeoff_tol_m_) {
    if (!pre_mode_sent_ || last_mode_cmd_.nanoseconds() == 0 || (now - last_mode_cmd_).seconds() > 1.0) {pre_mode_sent_ = true; last_mode_cmd_ = now; state_ = "select_adaptive_after_takeoff"; RCLCPP_WARN(node_->get_logger(), "Takeoff done, selecting Adaptive Mission Mode again"); setMode(static_cast<float>(exec_->id())); pubState();}
    return;
  }
  if (!pre_takeoff_sent_ || last_takeoff_cmd_.nanoseconds() == 0 || (now - last_takeoff_cmd_).seconds() > 2.0) {
    pre_takeoff_sent_ = true; last_takeoff_cmd_ = now; state_ = "mav_takeoff"; RCLCPP_WARN(node_->get_logger(), "Sending MAV_CMD_NAV_TAKEOFF to %.2f m AMSL", target); takeoff(static_cast<float>(target)); pubState();
  }
}

void App::cmd(uint32_t c, float p1, float p2, float p3, float p4, float p5, float p6, float p7)
{
  px4_msgs::msg::VehicleCommand m{}; m.timestamp = static_cast<uint64_t>(node_->now().nanoseconds() / 1000);
  m.command = c; m.param1 = p1; m.param2 = p2; m.param3 = p3; m.param4 = p4; m.param5 = p5; m.param6 = p6; m.param7 = p7;
  m.target_system = static_cast<uint8_t>(target_sys_); m.target_component = static_cast<uint8_t>(target_comp_);
  m.source_system = static_cast<uint8_t>(source_sys_); m.source_component = static_cast<uint8_t>(source_comp_);
  m.from_external = true; cmd_pub_->publish(m);
}

void App::arm() {cmd(px4_msgs::msg::VehicleCommand::VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0F);}
void App::setMode(float mode_id) {cmd(px4_msgs::msg::VehicleCommand::VEHICLE_CMD_SET_NAV_STATE, mode_id);}
void App::posctl() {setMode(2.0F);}
void App::rtl() {setMode(static_cast<float>(px4_ros2::ModeBase::kModeIDRtl));}
void App::takeoff(float alt_msl)
{
  float lat = nan(), lon = nan();
  if (gps_ && gps_->positionValid()) {const auto p = gps_->position(); lat = static_cast<float>(p.x()); lon = static_cast<float>(p.y());}
  cmd(px4_msgs::msg::VehicleCommand::VEHICLE_CMD_NAV_TAKEOFF, nan(), nan(), nan(), nan(), lat, lon, alt_msl);
}

double App::takeoffAlt() const
{
  if (plan_.takeoff_alt_msl) {return *plan_.takeoff_alt_msl;}
  if (plan_.json.contains("mission") && plan_.json.at("mission").contains("items")) {
    for (const auto & it : plan_.json.at("mission").at("items")) {if (it.value("type", "") == "navigation" && it.contains("z") && it.at("z").is_number()) {return it.at("z").get<double>();}}
  }
  return std::numeric_limits<double>::quiet_NaN();
}

bool App::needTakeoff() const
{
  if (!plan_.pre_takeoff) {return false;}
  const double target = takeoffAlt(); const double cur = altMsl();
  return std::isfinite(target) && (!std::isfinite(cur) || cur < target - takeoff_tol_m_);
}

float App::nan() {return std::numeric_limits<float>::quiet_NaN();}

double App::altMsl() const
{
  return gps_ && gps_->positionValid() ? gps_->position().z() : std::numeric_limits<double>::quiet_NaN();
}

nlohmann::json App::item(int i) const
{
  nlohmann::json o{{"index", i}, {"active", i == cur_}, {"done", cur_ >= 0 && i < cur_}};
  if (!plan_.json.contains("mission") || !plan_.json.at("mission").contains("items")) {o["valid"] = false; return o;}
  const auto & a = plan_.json.at("mission").at("items");
  if (!a.is_array() || i < 0 || i >= static_cast<int>(a.size())) {o["valid"] = false; return o;}
  const auto & it = a.at(i); o["valid"] = true; o["type"] = it.value("type", "unknown"); if (it.contains("id")) {o["id"] = it.at("id");}
  if (it.value("type", "") == "navigation") {const double z = it.value("z", 0.0); o["target"] = {{"lat", it.value("x", 0.0)}, {"lon", it.value("y", 0.0)}, {"z_msl", z}, {"z_with_offset_msl", z + off_.m()}, {"altitude_offset_m", off_.m()}};}
  if (it.contains("altitude")) {const double z = it.at("altitude").get<double>(); o["target"] = {{"z_msl", z}, {"z_with_offset_msl", z + off_.m()}, {"altitude_offset_m", off_.m()}};}
  return o;
}

nlohmann::json App::items() const
{
  nlohmann::json a = nlohmann::json::array(); const int n = plan_.json.contains("executable_item_count") ? plan_.json.at("executable_item_count").get<int>() : 0;
  for (int i = 0; i < n; ++i) {a.push_back(item(i));}
  return a;
}

nlohmann::json App::missionSummary() const
{
  nlohmann::json m{{"hash", plan_.hash}, {"source_format", plan_.json.value("source_format", "none")}, {"source_item_count", plan_.src_count}, {"executable_item_count", plan_.exec_count}, {"skipped_item_count", plan_.skip_count}, {"pre_takeoff", plan_.pre_takeoff}, {"current_item", item(cur_)}};
  if (pub_items_) {m["items"] = items();}
  else {m["items_omitted"] = true;}
  return m;
}

nlohmann::json App::state() const
{
  nlohmann::json j;
  j["state"] = state_; j["mission_loaded"] = loaded_; j["mission_ready"] = ready_; j["mission_pending_alt_ref"] = pending_; j["px4_mode_registered"] = reg_ok_; j["px4_mode_id"] = static_cast<int>(exec_->id()); j["fmu_topics_visible"] = fmu();
  j["mavlink_target"] = {{"target_system", target_sys_}, {"target_component", target_comp_}, {"source_system", source_sys_}, {"source_component", source_comp_}};
  j["active"] = active_; j["selected_by_status"] = reg_ok_ && exec_ && executor_ == static_cast<uint8_t>(exec_->id()); j["selected_by_user_intention"] = reg_ok_ && exec_ && (user_intent_ == static_cast<uint8_t>(exec_->id()) || nav_ == static_cast<uint8_t>(exec_->id())); j["armed"] = armed_; j["nav_state"] = nav_; j["nav_state_user_intention"] = user_intent_; j["arming_state"] = arm_state_; j["executor_in_charge"] = executor_; j["failsafe"] = failsafe_;
  j["pre_takeoff_active"] = pre_active_; j["pre_takeoff_sent"] = pre_takeoff_sent_; j["pre_takeoff_alt_msl"] = plan_.takeoff_alt_msl ? nlohmann::json(*plan_.takeoff_alt_msl) : nlohmann::json(nullptr); j["pause_rtl_resume"] = resumeState();
  j["current_index"] = cur_; j["altitude_offset_m"] = off_.m(); j["altitude_offset_rate_m_s"] = off_.rate(); j["altitude_offset_active"] = off_.active();
  j["mission"] = missionSummary();
  if (plan_.json.contains("remote_opaque_id")) {j["mission"]["remote_opaque_id"] = plan_.json.at("remote_opaque_id");}
  if (plan_.json.contains("source_hash")) {j["mission"]["source_hash"] = plan_.json.at("source_hash");}
  if (plan_.json.contains("skipped_source_items")) {j["mission"]["skipped_source_items"] = plan_.json.at("skipped_source_items");}
  if (gps_ && gps_->positionValid()) {const auto p = gps_->position(); j["vehicle"] = {{"global_position_valid", true}, {"lat", p.x()}, {"lon", p.y()}, {"alt_msl", p.z()}};} else {j["vehicle"] = {{"global_position_valid", false}};}
  return j;
}

void App::pubState()
{
  if (!state_pub_) {return;} std_msgs::msg::String m;
  try {m.data = state().dump();} catch (const std::exception & e) {m.data = nlohmann::json{{"state", state_}, {"state_error", e.what()}}.dump();}
  state_pub_->publish(m);
}

}  // namespace adaptive_mission_mode
