# adaptive_mission_mode clean v7 - auto arm via user intention

Clean custom PX4 ROS 2 mission mode. Node nhận mission JSON từ `fc_mission_reader` hoặc backend, ưu tiên `raw_items[]` của MAVLink mission, convert thành `px4_ros2::Mission`, rồi chỉ bay khi PX4 được chuyển sang **Adaptive Mission Mode**.

## Luồng đúng

```text
QGC/backend -> nạp mission vào PX4
fc_mission_reader/MAVSDK MissionRaw -> download raw mission -> publish /fc_mission_reader/mission_json
adaptive_mission_mode -> đọc raw_items[] -> setMission()
pilot/backend -> chuyển PX4 sang Adaptive Mission Mode -> node tự ARM + MAV_CMD_NAV_TAKEOFF nếu cần -> quay lại Adaptive Mission Mode -> mission chạy custom
```

Node này không gọi `MissionRaw.start_mission()` vì khi để PX4 chạy `AUTO.MISSION` thì custom mode không can thiệp được độ cao waypoint. MAVSDK/MissionRaw nên dùng ở node reader/backend để upload/download/import mission, còn node này chỉ execute mission theo logic adaptive.

## Topic

Input:
- `/fc_mission_reader/mission_json` (`std_msgs/String`): full JSON có `raw_items[]`.
- `/adaptive_mission_mode/mission_json` (`std_msgs/String`): test thủ công.
- `/adaptive_mission_mode/activate` (`std_msgs/Bool`): mặc định không dùng để start, chỉ dùng legacy khi `allow_activate_topic_start:=true`.
- `/adaptive_mission_mode/pause_rtl` (`std_msgs/Bool`): gửi RTL đơn giản.
- `/adaptive_mission_mode/continue_mission` (`std_msgs/Bool`): request lại Adaptive mode.

Output:
- `/adaptive_mission_mode/state` (`std_msgs/String`): state JSON cho UI.

## Params quan trọng

- `fc_mission_topic`: topic nhận mission từ reader, mặc định `/fc_mission_reader/mission_json`.
- `allow_activate_topic_start`: mặc định `false` để mission chỉ chạy khi PX4 chuyển sang Adaptive Mission Mode.
- `auto_arm_on_activate`: mặc định `true`, khi chọn Adaptive Mode trên mặt đất node tự gửi ARM.
- `auto_takeoff_on_activate`: mặc định `true`, nếu mission có takeoff đầu tiên node sẽ gửi `MAV_CMD_NAV_TAKEOFF` trước, sau đó tự chọn lại Adaptive Mode để bay waypoint.
- `takeoff_acceptance_m`: mặc định `0.7`, ngưỡng xem như đã takeoff xong.
- `target_system`, `target_component`, `source_system`, `source_component`: dùng cho `VehicleCommand`, mặc định `1/1/1/1`.

## Build

```bash
cd ~/mission-mode-executor-arch
rm -rf src/adaptive_mission_mode
unzip adaptive_mission_mode_clean.zip -d src
source /opt/ros/humble/setup.bash
colcon build --symlink-install --packages-select adaptive_mission_mode
source install/setup.bash
```

## Run

```bash
ros2 launch adaptive_mission_mode adaptive_mission_mode.launch.py
```

Cần thấy:

```text
Adaptive Mission Mode registered
Loaded mission: src=34 exec=25 skip=9
```

Kiểm tra UI/state:

```bash
ros2 topic echo --once /adaptive_mission_mode/state
```

Cần thấy:

```json
{
  "mission_loaded": true,
  "mission": {
    "source_format": "mavlink_mission_protocol_raw_items",
    "source_item_count": 34,
    "executable_item_count": 25,
    "skipped_item_count": 9
  }
}
```

## JSON hỗ trợ

Ưu tiên đúng MAVLink:

```json
{
  "source": "mavlink_mission_protocol",
  "item_count": 34,
  "raw_items": [
    {"seq": 1, "frame": 6, "command": 22, "x": 47.3979710, "y": 8.5461636, "z": 50.0},
    {"seq": 3, "frame": 6, "command": 16, "x": 47.3974796, "y": 8.5458039, "z": 50.0},
    {"seq": 33, "frame": 2, "command": 20}
  ]
}
```

Convert command:
- `22 MAV_CMD_NAV_TAKEOFF` -> pre-takeoff bằng `VehicleCommand`, không đưa vào danh sách waypoint nội bộ
- `16 MAV_CMD_NAV_WAYPOINT` -> `navigation waypoint`
- `21 MAV_CMD_NAV_LAND` -> optional waypoint + `land`
- `20 MAV_CMD_NAV_RETURN_TO_LAUNCH` -> `rtl`
- DO/camera/action command như `206`, `530` -> skip và báo trong `skipped_source_items`

`nan`, `NaN`, `Infinity` trong JSON input sẽ được đổi thành `null` trước khi parse.

## Throttle altitude offset

Khi mission active + armed + manual input valid:

```text
throttle > deadband -> altitude_offset_m tăng dần
waypoint_z_command = waypoint_z_msl + altitude_offset_m
```

Offset chỉ áp dụng cho waypoint global do custom `OffsetExec` phát setpoint. Khi mission kết thúc/deactivate, offset reset về 0.

## Auto takeoff khi chọn Adaptive Mission Mode

Bản này tách takeoff ra khỏi mission executor. Khi mission từ PX4 có item đầu là `MAV_CMD_NAV_TAKEOFF`, node lưu nó thành `pre_takeoff_alt_msl`. Lúc bạn chọn **Adaptive Mission Mode** trên QGC/backend:

```text
Adaptive Mode active lần 1
-> nếu chưa đủ cao: ARM nếu cần
-> gửi VEHICLE_CMD_NAV_TAKEOFF, param7 = altitude AMSL
-> PX4 có thể chuyển sang Takeoff mode
-> khi alt_msl >= target - takeoff_acceptance_m
-> node tự gửi SET_NAV_STATE về Adaptive Mission Mode
-> MissionExecutor chạy các waypoint còn lại với altitude_offset_m
```

State cần thấy:

```json
{
  "state": "mav_takeoff | select_adaptive_after_takeoff | mission",
  "pre_takeoff_active": true,
  "pre_takeoff_alt_msl": 538.0,
  "mission": {"pre_takeoff": true}
}
```


## V4 fixes

- During MAV takeoff pre-stage, the trajectory executor is held, so waypoint setpoints are not published before takeoff finishes.
- Removed `px4_ros2::geodesic` helper calls from the high-rate executor path to stop repeated `Map projection reference point has been reset` warnings.
- `/adaptive_mission_mode/state` now publishes a compact mission summary by default. Set `publish_full_item_list:=true` only when debugging UI item details.


## v5 notes

This version starts the auto arm/takeoff pre-stage not only from `onActivated()`, but also when `VehicleStatus.executor_in_charge` shows that the Adaptive mode was selected before the custom executor becomes active. It also subscribes `/fmu/out/vehicle_command_ack` and logs ACK/NACK for ARM, NAV_TAKEOFF and SET_NAV_STATE.

If the vehicle still does not arm, check the ACK log. Result `0` means accepted; non-zero means PX4 rejected the command, normally because of preflight checks, safety, commander state, or arming permissions.

## Pause RTL and continue behavior

`/adaptive_mission_mode/pause_rtl` now saves the vehicle global position and AMSL altitude at the exact pause moment. It builds a resume mission where the first item is this saved pause point, followed by the remaining items from the mission item that was being executed next. If altitude offset was active, the current offset is baked into the remaining waypoint altitudes so the resumed path preserves the pilot-adjusted altitude.

`/adaptive_mission_mode/continue_mission` loads that resume mission, selects Adaptive Mission Mode again, auto-takeoffs to the saved pause altitude if the vehicle has already landed/disarmed, flies back to the saved pause point, then continues the rest of the mission.

While a pause resume point is pending, mission reloads from `/fc_mission_reader/mission_json` are ignored so the saved resume route is not overwritten by the periodically republished FC mission.
