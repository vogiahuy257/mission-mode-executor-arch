from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='adaptive_mission_mode',
            executable='adaptive_mission_mode_node',
            name='adaptive_mission_mode',
            output='screen',
            parameters=[{
                'mission_topic': '~/mission_json',
                'fc_mission_topic': '/fc_mission_reader/mission_json',
                'allow_activate_topic_start': False,
                'auto_arm_on_activate': True,
                'auto_takeoff_on_activate': True,
                'takeoff_acceptance_m': 0.7,
                'publish_full_item_list': False,
                'target_system': 1,
                'target_component': 1,
                'source_system': 1,
                'source_component': 1,
            }],
        )
    ])
