#pragma once
#include <functional>
#include <memory>
#include <optional>
#include <Eigen/Eigen>
#include <px4_ros2/components/mode.hpp>
#include <px4_ros2/control/setpoint_types/multicopter/goto.hpp>
#include <px4_ros2/mission/trajectory/trajectory_executor.hpp>
#include <px4_ros2/odometry/global_position.hpp>
#include <rclcpp/rclcpp.hpp>

namespace adaptive_mission_mode
{

class OffsetExec final : public px4_ros2::TrajectoryExecutorInterface
{
public:
  OffsetExec(px4_ros2::ModeBase & mode, std::function<float()> off, std::function<bool()> hold);
  bool navigationItemTypeSupported(px4_ros2::NavigationItemType type) override;
  bool frameSupported(px4_ros2::MissionFrame frame) override;
  void runTrajectory(const TrajectoryConfig & cfg) override;
  void updateSetpoint() override;

private:
  void next();
  bool near(const Eigen::Vector3d & p, float r) const;
  rclcpp::Node & node_;
  std::function<float()> off_;
  std::function<bool()> hold_;
  TrajectoryConfig tr_{};
  std::optional<int> idx_{};
  std::shared_ptr<px4_ros2::OdometryGlobalPosition> gps_;
  std::shared_ptr<px4_ros2::MulticopterGotoGlobalSetpointType> sp_;
};

}  // namespace adaptive_mission_mode
