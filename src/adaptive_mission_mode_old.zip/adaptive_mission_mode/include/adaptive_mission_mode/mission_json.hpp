#pragma once
#include <string>
#include <optional>
#include <px4_ros2/third_party/nlohmann/json.hpp>

namespace adaptive_mission_mode
{

struct PlanInfo
{
  nlohmann::json json{nlohmann::json::object()};
  std::string hash{};
  int src_count{};
  int exec_count{};
  int skip_count{};
  bool pre_takeoff{};
  std::optional<double> takeoff_alt_msl{};
};

PlanInfo parsePlan(const std::string & text, double ref_alt_msl);
std::string missionKey(const std::string & text);

}  // namespace adaptive_mission_mode
