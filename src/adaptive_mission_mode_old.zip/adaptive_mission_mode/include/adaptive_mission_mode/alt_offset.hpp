#pragma once
#include <chrono>

namespace adaptive_mission_mode
{

class AltOffset
{
public:
  void reset();
  void tick(float stick, bool on, std::chrono::steady_clock::time_point now);
  float m() const {return m_;}
  float rate() const {return rate_;}
  bool active() const {return active_;}

private:
  static constexpr float dead_ = 0.18F;
  static constexpr float max_rate_ = 2.0F;
  static constexpr float lim_ = 50.0F;
  float m_{};
  float rate_{};
  bool active_{};
  std::chrono::steady_clock::time_point last_{};
};

}  // namespace adaptive_mission_mode
