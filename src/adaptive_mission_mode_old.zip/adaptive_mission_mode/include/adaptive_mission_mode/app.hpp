#pragma once
#include <functional>
#include <memory>
#include <string>
#include <vector>
#include <px4_msgs/msg/vehicle_command.hpp>
#include <px4_msgs/msg/vehicle_command_ack.hpp>
#include <px4_msgs/msg/vehicle_status.hpp>
#include <px4_ros2/components/manual_control_input.hpp>
#include <px4_ros2/mission/mission_executor.hpp>
#include <px4_ros2/odometry/global_position.hpp>
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/bool.hpp>
#include <std_msgs/msg/string.hpp>
#include "adaptive_mission_mode/alt_offset.hpp"
#include "adaptive_mission_mode/mission_json.hpp"

namespace adaptive_mission_mode
{

class Exec final : public px4_ros2::MissionExecutor
{
public:
  explicit Exec(rclcpp::Node & node, std::function<float()> off, std::function<bool()> hold);
  px4_ros2::ModeBase::ModeID id() const {return modeId();}
  px4_ros2::ModeExecutorBase & base() {return modeExecutor();}
};

class App
{
public:
  explicit App(std::shared_ptr<rclcpp::Node> node);

private:
  void bind();
  void reg();
  void load(const std::string & text);
  void start(bool on);
  void stop();
  void pauseRtl();
  void continueMission();
  bool saveResume();
  bool applyResume();
  nlohmann::json resumeState() const;
  void status(const px4_msgs::msg::VehicleStatus & msg);
  void ack(const px4_msgs::msg::VehicleCommandAck & msg);
  void beginPre(const char * reason);
  void altTick();
  void preTick();
  void pubState();
  void retryPending();
  void cmd(uint32_t c, float p1 = nan(), float p2 = nan(), float p3 = nan(), float p4 = nan(), float p5 = nan(), float p6 = nan(), float p7 = nan());
  void arm();
  void setMode(float mode_id);
  void posctl();
  void rtl();
  void takeoff(float alt_msl);
  double takeoffAlt() const;
  bool needTakeoff() const;
  bool fmu() const;
  double altMsl() const;
  nlohmann::json item(int i) const;
  nlohmann::json items() const;
  nlohmann::json missionSummary() const;
  nlohmann::json state() const;
  static float nan();

  std::shared_ptr<rclcpp::Node> node_;
  std::unique_ptr<Exec> exec_;
  std::unique_ptr<px4_ros2::ManualControlInput> stick_;
  std::unique_ptr<px4_ros2::OdometryGlobalPosition> gps_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr state_pub_;
  rclcpp::Publisher<px4_msgs::msg::VehicleCommand>::SharedPtr cmd_pub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr mission_sub_, fc_sub_;
  rclcpp::Subscription<std_msgs::msg::Bool>::SharedPtr act_sub_, pause_sub_, cont_sub_;
  rclcpp::Subscription<px4_msgs::msg::VehicleStatus>::SharedPtr status_sub_;
  rclcpp::Subscription<px4_msgs::msg::VehicleCommandAck>::SharedPtr ack_sub_;
  rclcpp::TimerBase::SharedPtr reg_timer_, alt_timer_, state_timer_, retry_timer_, pre_timer_;
  AltOffset off_;
  PlanInfo plan_;
  std::string src_key_, pending_text_, pending_key_;
  bool pending_{};
  std::string state_{"idle"};
  std::string mission_topic_, fc_topic_;
  bool allow_start_{};
  bool auto_arm_{};
  bool auto_takeoff_{};
  bool pub_items_{};
  double takeoff_tol_m_{};
  int target_sys_{1};
  int target_comp_{1};
  int source_sys_{1};
  int source_comp_{1};
  bool loaded_{};
  bool ready_{};
  bool reg_ok_{};
  bool active_{};
  bool resume_pending_{};
  bool pre_active_{};
  bool pre_takeoff_sent_{};
  bool pre_mode_sent_{};
  bool armed_{};
  bool failsafe_{};
  uint8_t nav_{};
  uint8_t user_intent_{};
  uint8_t arm_state_{};
  uint8_t executor_{};
  int cur_{-1};
  int resume_index_{};
  float resume_offset_{};
  nlohmann::json resume_json_{nlohmann::json::object()};
  nlohmann::json resume_info_{nlohmann::json::object()};
  rclcpp::Time last_reg_log_{};
  rclcpp::Time last_reg_try_{};
  rclcpp::Time last_alt_log_{};
  rclcpp::Time last_arm_cmd_{};
  rclcpp::Time last_takeoff_cmd_{};
  rclcpp::Time last_mode_cmd_{};
  rclcpp::Time last_select_watch_log_{};
};

}  // namespace adaptive_mission_mode
