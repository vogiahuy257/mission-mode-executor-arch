# fc_mission_reader

ROS 2 C++ node đọc full mission đang lưu trong FC bằng MAVLink Mission Protocol, publish JSON và lưu `data.json`.

## Logic cache

- Lần đầu node sẽ download full mission một lần.
- Sau đó node chỉ nghe `MISSION_CURRENT.mission_id` và `MISSION_ACK.opaque_id`.
- Nếu mission id/opaque id đổi, node mới download full mission lại một lần.
- Nếu mission không đổi, node chỉ publish lại JSON đang cache, không ghi file lại.
- Có thể bật fallback poll nhẹ `MISSION_REQUEST_LIST` bằng `enable_fallback_count_poll:=true` nếu FC không stream `MISSION_CURRENT.mission_id`.

## Build

```bash
sudo apt update
sudo apt install ros-humble-mavlink

cd ~/mission-mode-executor-arch/src
rm -rf fc_mission_reader
unzip /path/to/fc_mission_reader_event_cached.zip

cd ~/mission-mode-executor-arch
source /opt/ros/humble/setup.bash
colcon build --symlink-install --packages-select fc_mission_reader
source install/setup.bash
```

## Run với mavlink-router

Ví dụ router gửi MAVLink tới máy đang chạy node tại port `14551`:

```bash
mavlink-routerd \
  -e 10.5.10.25:14550 \
  -e 10.5.10.25:14551 \
  0.0.0.0:14550
```

Chạy reader:

```bash
ros2 launch fc_mission_reader fc_mission_reader.launch.py \
  bind_ip:=0.0.0.0 \
  bind_port:=14551 \
  auto_target:=true \
  poll_period_s:=3.0
```

Không cần truyền `target_ip/target_port` nếu `auto_target:=true`.
Node sẽ tự học peer MAVLink từ packet nhận được.

## Output

Topic:

```bash
ros2 topic echo /fc_mission_reader/mission_json
```

File:

```bash
cat ~/mission-mode-executor-arch/src/fc_mission_reader/data.json | jq .
```

Nếu không dùng `--symlink-install`, file nằm trong:

```bash
cat ~/mission-mode-executor-arch/install/fc_mission_reader/share/fc_mission_reader/data.json | jq .
```

## Nạp sang adaptive_mission_mode

```bash
MISSION_JSON=$(cat ~/mission-mode-executor-arch/src/fc_mission_reader/data.json | jq -c '.mission')

ros2 topic pub --once /adaptive_mission_mode/mission_json std_msgs/msg/String \
  "{data: '$MISSION_JSON'}"
```

