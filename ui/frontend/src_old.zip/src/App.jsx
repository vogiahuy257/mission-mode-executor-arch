import { Suspense, lazy, memo, useEffect, useMemo, useRef, useState } from "react";


const API_BASE = import.meta.env.VITE_API_BASE ?? "";

const DEFAULT_DEFAULTS = {
  horizontal_velocity_m_s: 5,
  vertical_velocity_m_s: 2,
  max_heading_rate_deg_s: 60,
};

const EMPTY_STATUS = {
  ros_ready: false,
  mission_topic: "/adaptive_mission_mode/mission_json",
  activate_topic: "/adaptive_mission_mode/activate_json",
  vehicle: {
    connected: false,
    flight_mode: null,
    nav_state: null,
    executor_in_charge: null,
    armed: false,
    preflight_checks_pass: null,
    failsafe: null,
    system_id: null,
    component_id: null,
    battery_percent: null,
    last_status_age_s: null,
    last_position_age_s: null,
    last_battery_age_s: null,
    position: {
      latitude_deg: null,
      longitude_deg: null,
      altitude_amsl_m: null,
    },
  },
  mission_cache: {
    loaded: false,
    mission_name: null,
    item_count: 0,
    last_mission_publish_at: null,
    last_activate_publish_at: null,
  },
  mission_runtime: {
    available: false,
    runtime_state: null,
    active_bt_branch: null,
    mission_ready: null,
    mission_active: null,
    mission_start_in_progress: null,
    current_item_index: null,
    manual_altitude_active: null,
    altitude_offset_m: null,
    throttle_input: null,
    last_error: null,
    last_update_age_s: null,
  },
  mavlink: {
    enabled: false,
    connected: false,
    connection_url: null,
    target_system: null,
    target_component: null,
    autopilot: null,
    mav_type: null,
    base_mode: null,
    custom_mode: null,
    system_status: null,
    armed: false,
    battery_percent: null,
    voltage_battery_v: null,
    current_battery_a: null,
    latitude_deg: null,
    longitude_deg: null,
    altitude_amsl_m: null,
    relative_altitude_m: null,
    heading_deg: null,
    yaw_deg: null,
    roll_deg: null,
    pitch_deg: null,
    last_heartbeat_age_s: null,
    last_message_age_s: null,
    last_error: null,
    last_statustext: null,
    message_counts: {},
  },
};

const TILE_SIZE = 256;
const MIN_MAP_ZOOM = 3;
const MAX_MAP_ZOOM = 20;
const DEFAULT_MAP_CENTER = { latitude_deg: 10.823099, longitude_deg: 106.629662 };
const MAP_3D_PITCH_SCALE = 0.66;
// Vì tile OSM không có địa hình/độ cao, UI dựng 3D giả lập bằng cách nâng marker theo altitude_m.
// Scale này chỉ dùng để hiển thị trực quan, không làm đổi dữ liệu mission gửi xuống backend.
const MAP_3D_ALTITUDE_SCALE = 1.55;
const MAP_3D_MAX_VISUAL_ALTITUDE_M = 120;
const MAX_FLIGHT_TRACK_JUMP_M = 120;


const PX4_MAIN_MODE = {
  1: "MANUAL",
  2: "ALTCTL",
  3: "POSCTL",
  4: "AUTO",
  5: "ACRO",
  6: "OFFBOARD",
  7: "STABILIZED",
  8: "RATTITUDE",
  9: "SIMPLE",
};

const PX4_AUTO_SUB_MODE = {
  1: "READY",
  2: "TAKEOFF",
  3: "LOITER",
  4: "MISSION",
  5: "RTL",
  6: "LAND",
  7: "RTGS",
  8: "FOLLOW_TARGET",
  9: "PRECLAND",
  10: "VTOL_TAKEOFF",
  11: "EXTERNAL1",
  12: "EXTERNAL2",
  13: "EXTERNAL3",
  14: "EXTERNAL4",
  15: "EXTERNAL5",
  16: "EXTERNAL6",
  17: "EXTERNAL7",
  18: "EXTERNAL8",
};

const MISSION_ICON = {
  takeoff: "rocket_launch",
  waypoint: "add_location_alt",
  hold: "pause_circle",
  land: "flight_land",
  rtl: "home_pin",
};

const MISSION_LABEL = {
  takeoff: "TO",
  waypoint: "WP",
  hold: "HOLD",
  land: "LAND",
  rtl: "RTL",
};

const MISSION_MARKER_STYLE = {
  takeoff: "border-emerald-100 bg-emerald-400 text-zinc-950 ring-emerald-300/20",
  waypoint: "border-cyan-100 bg-cyan-400 text-zinc-950 ring-cyan-300/20",
  hold: "border-amber-100 bg-amber-300 text-zinc-950 ring-amber-300/20",
  land: "border-violet-100 bg-violet-400 text-zinc-950 ring-violet-300/20",
  rtl: "border-rose-100 bg-rose-400 text-zinc-950 ring-rose-300/20",
};

const MAP_COORDINATE_ITEM_TYPES = new Set(["waypoint", "hold", "land"]);

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function clampLatitude(latitude) {
  return clamp(latitude, -85.05112878, 85.05112878);
}

function hasValidCoordinate(latitude, longitude) {
  return Number.isFinite(Number(latitude)) && Number.isFinite(Number(longitude));
}

function isDroneArmed(status) {
  return Boolean(status?.mavlink?.armed || status?.vehicle?.armed);
}

function haversineDistanceMeters(a, b) {
  if (!hasValidCoordinate(a?.latitude_deg, a?.longitude_deg) || !hasValidCoordinate(b?.latitude_deg, b?.longitude_deg)) {
    return Number.POSITIVE_INFINITY;
  }

  const earthRadiusM = 6371000;
  const lat1 = Number(a.latitude_deg) * Math.PI / 180;
  const lat2 = Number(b.latitude_deg) * Math.PI / 180;
  const dLat = (Number(b.latitude_deg) - Number(a.latitude_deg)) * Math.PI / 180;
  const dLon = (Number(b.longitude_deg) - Number(a.longitude_deg)) * Math.PI / 180;
  const sinLat = Math.sin(dLat / 2);
  const sinLon = Math.sin(dLon / 2);
  const h = sinLat * sinLat + Math.cos(lat1) * Math.cos(lat2) * sinLon * sinLon;
  return 2 * earthRadiusM * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

function itemCanUseMapCoordinate(item) {
  return MAP_COORDINATE_ITEM_TYPES.has(item?.type);
}

function findFirstMissionCoordinate(items, livePosition) {
  const firstItem = items.find((item) => hasValidCoordinate(item.latitude_deg, item.longitude_deg));
  if (firstItem) {
    return {
      latitude_deg: Number(firstItem.latitude_deg),
      longitude_deg: Number(firstItem.longitude_deg),
    };
  }

  if (hasValidCoordinate(livePosition?.latitude_deg, livePosition?.longitude_deg)) {
    return {
      latitude_deg: Number(livePosition.latitude_deg),
      longitude_deg: Number(livePosition.longitude_deg),
    };
  }

  return null;
}

function getMissionMarkerCoordinate(item, index, items, livePosition) {
  if (item.type === "rtl") {
    if (hasValidCoordinate(livePosition?.latitude_deg, livePosition?.longitude_deg)) {
      return {
        latitude_deg: Number(livePosition.latitude_deg),
        longitude_deg: Number(livePosition.longitude_deg),
        fromFallback: true,
        fromDrone: true,
      };
    }

    const homeCoordinate = findFirstMissionCoordinate(items, null);
    return homeCoordinate ? { ...homeCoordinate, fromFallback: true } : null;
  }

  if (hasValidCoordinate(item.latitude_deg, item.longitude_deg)) {
    return {
      latitude_deg: Number(item.latitude_deg),
      longitude_deg: Number(item.longitude_deg),
      fromFallback: false,
    };
  }

  if (itemCanUseMapCoordinate(item)) {
    const previousItem = items
      .slice(0, index)
      .reverse()
      .find((candidate) => hasValidCoordinate(candidate.latitude_deg, candidate.longitude_deg));

    if (previousItem) {
      return {
        latitude_deg: Number(previousItem.latitude_deg),
        longitude_deg: Number(previousItem.longitude_deg),
        fromFallback: true,
      };
    }
  }

  return null;
}

function decodePx4Mode(customMode) {
  if (!Number.isFinite(Number(customMode))) {
    return "--";
  }

  const value = Number(customMode) >>> 0;
  const mainMode = (value >> 16) & 0xff;
  const subMode = (value >> 24) & 0xff;
  const mainName = PX4_MAIN_MODE[mainMode] ?? `MAIN_${mainMode}`;

  if (mainMode === 4 && subMode > 0) {
    return `${mainName}/${PX4_AUTO_SUB_MODE[subMode] ?? `SUB_${subMode}`}`;
  }

  return mainName;
}

function getLivePosition(status) {
  const mavlink = status?.mavlink ?? {};
  if (mavlink.connected && hasValidCoordinate(mavlink.latitude_deg, mavlink.longitude_deg)) {
    return {
      latitude_deg: mavlink.latitude_deg,
      longitude_deg: mavlink.longitude_deg,
      altitude_amsl_m: mavlink.altitude_amsl_m,
      relative_altitude_m: mavlink.relative_altitude_m,
      source: "MAVLink",
    };
  }

  const rosPosition = status?.vehicle?.position ?? {};
  if (hasValidCoordinate(rosPosition.latitude_deg, rosPosition.longitude_deg)) {
    return { ...rosPosition, relative_altitude_m: null, source: "ROS 2" };
  }

  return {
    latitude_deg: null,
    longitude_deg: null,
    altitude_amsl_m: null,
    relative_altitude_m: null,
    source: "none",
  };
}

function getDroneTelemetry(status) {
  const mavlink = status?.mavlink ?? {};
  const vehicle = status?.vehicle ?? {};
  const hasMavlink = mavlink.enabled || mavlink.connected || mavlink.last_message_age_s != null;

  return {
    id: `${mavlink.target_system ?? vehicle.system_id ?? 1}:${mavlink.target_component ?? vehicle.component_id ?? 1}`,
    name: `Drone ${mavlink.target_system ?? vehicle.system_id ?? 1}`,
    source: hasMavlink ? "MAVLink" : "ROS 2",
    connected: hasMavlink ? Boolean(mavlink.connected) : Boolean(vehicle.connected),
    armed: hasMavlink ? Boolean(mavlink.armed) : Boolean(vehicle.armed),
    mode: hasMavlink ? decodePx4Mode(mavlink.custom_mode) : vehicle.flight_mode ?? "--",
    navState: vehicle.nav_state ?? "--",
    preflight: vehicle.preflight_checks_pass,
    failsafe: vehicle.failsafe,
    batteryPercent: mavlink.battery_percent ?? vehicle.battery_percent,
    voltage: mavlink.voltage_battery_v,
    current: mavlink.current_battery_a,
    headingDeg: mavlink.heading_deg ?? mavlink.yaw_deg ?? null,
    yawDeg: mavlink.yaw_deg ?? null,
    rollDeg: mavlink.roll_deg ?? null,
    pitchDeg: mavlink.pitch_deg ?? null,
    baseMode: mavlink.base_mode,
    customMode: mavlink.custom_mode,
    systemStatus: mavlink.system_status,
    autopilot: mavlink.autopilot,
    mavType: mavlink.mav_type,
    targetSystem: mavlink.target_system ?? vehicle.system_id,
    targetComponent: mavlink.target_component ?? vehicle.component_id,
    heartbeatAge: mavlink.last_heartbeat_age_s,
    messageAge: mavlink.last_message_age_s ?? vehicle.last_status_age_s,
    positionAge: vehicle.last_position_age_s,
    connectionUrl: mavlink.connection_url,
    lastError: mavlink.last_error,
    lastStatustext: mavlink.last_statustext,
    messageCounts: mavlink.message_counts ?? {},
  };
}

function getDroneOptions(status) {
  if (Array.isArray(status?.drones) && status.drones.length > 0) {
    return status.drones.map((drone, index) => ({
      id: String(drone.id ?? `${drone.system_id ?? index + 1}:${drone.component_id ?? 1}`),
      name: drone.name ?? `Drone ${drone.system_id ?? index + 1}`,
      connected: Boolean(drone.connected),
      armed: Boolean(drone.armed),
      batteryPercent: drone.battery_percent,
      mode: drone.flight_mode ?? drone.mode ?? "--",
    }));
  }

  const drone = getDroneTelemetry(status);
  return [drone];
}

function latLonToWorld(latitude, longitude, zoom) {
  const lat = clampLatitude(Number(latitude));
  const lon = clamp(Number(longitude), -180, 180);
  const sinLat = Math.sin((lat * Math.PI) / 180);
  const scale = TILE_SIZE * 2 ** zoom;

  return {
    x: ((lon + 180) / 360) * scale,
    y: (0.5 - Math.log((1 + sinLat) / (1 - sinLat)) / (4 * Math.PI)) * scale,
  };
}

function worldToLatLon(x, y, zoom) {
  const scale = TILE_SIZE * 2 ** zoom;
  const longitude = (x / scale) * 360 - 180;
  const n = Math.PI - (2 * Math.PI * y) / scale;
  const latitude = (180 / Math.PI) * Math.atan(Math.sinh(n));

  return {
    latitude_deg: clampLatitude(latitude),
    longitude_deg: ((longitude + 540) % 360) - 180,
  };
}

function formatAge(value) {
  if (value == null || !Number.isFinite(Number(value))) {
    return "--";
  }
  return `${Number(value).toFixed(1)}s`;
}

function formatCoordinate(value) {
  if (value == null || value === "" || !Number.isFinite(Number(value))) {
    return "--";
  }
  return Number(value).toFixed(7);
}

function formatSmallNumber(value, digits = 2, suffix = "") {
  if (value == null || value === "" || !Number.isFinite(Number(value))) {
    return "--";
  }
  return `${Number(value).toFixed(digits)}${suffix}`;
}

function formatLinkSummary(value) {
  if (!value) {
    return "--";
  }

  const text = String(value);
  const udpMatch = text.match(/:(\d+)$/);
  if (text.includes("udp") && udpMatch) {
    return `UDP ${udpMatch[1]}`;
  }
  return text;
}

function getVisualAltitudeM(item, livePosition) {
  if (Number.isFinite(Number(item?.altitude_m))) {
    return Math.max(0, Number(item.altitude_m));
  }
  if (Number.isFinite(Number(livePosition?.relative_altitude_m))) {
    return Math.max(0, Number(livePosition.relative_altitude_m));
  }
  return 0;
}

function formatAltitudeLabel(value) {
  if (!Number.isFinite(Number(value))) {
    return "-- m";
  }
  const numeric = Number(value);
  if (Math.abs(numeric) >= 100) {
    return `${numeric.toFixed(0)} m`;
  }
  return `${numeric.toFixed(1)} m`;
}

function normalizeNumber(value) {
  if (value === "" || value === null || value === undefined) {
    return null;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function getTakeoffAltitude(missionItems, status) {
  const takeoffItem = Array.isArray(missionItems)
    ? missionItems.find((item) => item.type === "takeoff" && Number.isFinite(Number(item.altitude_m)))
    : null;
  if (takeoffItem) {
    return Number(takeoffItem.altitude_m);
  }

  const livePosition = getLivePosition(status ?? EMPTY_STATUS);
  if (Number.isFinite(Number(livePosition.relative_altitude_m)) && Number(livePosition.relative_altitude_m) > 0.5) {
    return Number(livePosition.relative_altitude_m);
  }
  return 20;
}

function createMissionItem(type, status, missionItems = []) {
  const position = getLivePosition(status ?? EMPTY_STATUS);
  const latitude = position.latitude_deg ?? "";
  const longitude = position.longitude_deg ?? "";
  const altitude = position.altitude_amsl_m ?? "";
  const takeoffAltitude = getTakeoffAltitude(missionItems, status ?? EMPTY_STATUS);
  const mapAltitude = Number.isFinite(Number(takeoffAltitude)) ? Number(takeoffAltitude) : 20;

  if (type === "waypoint") {
    return {
      type,
      name: "Waypoint",
      latitude_deg: latitude,
      longitude_deg: longitude,
      altitude_m: mapAltitude,
      hold_time_s: 0,
    };
  }

  if (type === "hold") {
    return {
      type,
      name: "Hold",
      latitude_deg: latitude,
      longitude_deg: longitude,
      altitude_m: mapAltitude,
      hold_time_s: 5,
    };
  }

  if (type === "takeoff") {
    return {
      type,
      name: "Takeoff",
      latitude_deg: "",
      longitude_deg: "",
      altitude_m: mapAltitude,
      hold_time_s: 0,
    };
  }

  if (type === "land") {
    return {
      type,
      name: "Land",
      latitude_deg: latitude,
      longitude_deg: longitude,
      altitude_m: altitude !== "" && altitude != null ? Number(altitude) : "",
      hold_time_s: 0,
    };
  }

  return {
    type,
    name: type.toUpperCase(),
    latitude_deg: "",
    longitude_deg: "",
    altitude_m: "",
    hold_time_s: 0,
  };
}

function missionPayload(name, defaults, items) {
  return {
    mission: {
      name,
      defaults: {
        horizontal_velocity_m_s: Number(defaults.horizontal_velocity_m_s),
        vertical_velocity_m_s: Number(defaults.vertical_velocity_m_s),
        max_heading_rate_deg_s: Number(defaults.max_heading_rate_deg_s),
      },
      items: items.map((item) => ({
        type: item.type,
        name: item.name,
        latitude_deg: normalizeNumber(item.latitude_deg),
        longitude_deg: normalizeNumber(item.longitude_deg),
        altitude_m: normalizeNumber(item.altitude_m),
        hold_time_s: Number(item.hold_time_s || 0),
      })),
    },
  };
}

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers ?? {}),
    },
    ...options,
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.detail ?? "Request failed");
  }
  return data;
}

function Icon({ name, className = "", ...props }) {
  return <span className={`material-symbols-rounded select-none ${className}`} {...props}>{name}</span>;
}

function GlassButton({ icon, label, tone = "zinc", disabled = false, onClick }) {
  const toneMap = {
    zinc: "border-white/10 bg-white/10 text-zinc-100 hover:bg-white/20",
    cyan: "border-cyan-300/30 bg-cyan-400/15 text-cyan-50 hover:bg-cyan-400/25",
    emerald: "border-emerald-300/30 bg-emerald-400/15 text-emerald-50 hover:bg-emerald-400/25",
    amber: "border-amber-300/30 bg-amber-400/15 text-amber-50 hover:bg-amber-400/25",
    rose: "border-rose-300/30 bg-rose-400/15 text-rose-50 hover:bg-rose-400/25",
  };

  return (
    <button
      type="button"
      disabled={disabled}
      onPointerDown={(event) => event.stopPropagation()}
      onClick={(event) => {
        event.stopPropagation();
        onClick?.(event);
      }}
      className={`inline-flex items-center justify-center gap-2 rounded-2xl border px-3 py-2 text-sm font-bold transition disabled:cursor-not-allowed disabled:opacity-40 ${toneMap[tone]}`}
    >
      {icon ? <Icon name={icon} className="text-[20px]" /> : null}
      {label ? <span>{label}</span> : null}
    </button>
  );
}

function MiniIconButton({ icon, label, onClick, disabled = false }) {
  return (
    <button
      type="button"
      title={label}
      disabled={disabled}
      onPointerDown={(event) => event.stopPropagation()}
      onClick={(event) => {
        event.stopPropagation();
        onClick?.(event);
      }}
      className="grid h-11 w-11 place-items-center rounded-2xl border border-white/10 bg-zinc-950/80 text-zinc-100 shadow-[0_12px_32px_rgba(0,0,0,0.35)] backdrop-blur-sm transition hover:bg-white/15 disabled:cursor-not-allowed disabled:opacity-40"
    >
      <Icon name={icon} className="text-[22px]" />
    </button>
  );
}

function Field({ label, children }) {
  return (
    <label className="grid gap-1.5">
      <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-zinc-500">{label}</span>
      {children}
    </label>
  );
}

const MissionMap = memo(function MissionMap({
  status,
  missionItems,
  selectedIndex,
  waypointPlacementMode,
  flightTrack,
  onSelectItem,
  onUpdateWaypointFromMap,
  onAppendWaypointFromMap,
  onToggleWaypointPlacement,
  onClearFlightTrack,
  onOpenThreeEditor,
}) {
  const mapRef = useRef(null);
  const dragRef = useRef(null);
  const markerDragRef = useRef(null);
  const mapDragRafRef = useRef(null);
  const lastWheelZoomAtRef = useRef(0);
  const [size, setSize] = useState({ width: 1024, height: 768 });
  const [zoom, setZoom] = useState(18);
  const [autoFollow, setAutoFollow] = useState(true);
  const livePosition = getLivePosition(status);
  const droneTelemetry = getDroneTelemetry(status);
  const hasLivePosition = hasValidCoordinate(livePosition.latitude_deg, livePosition.longitude_deg);
  const [center, setCenter] = useState(() => ({
    latitude_deg: hasLivePosition ? Number(livePosition.latitude_deg) : DEFAULT_MAP_CENTER.latitude_deg,
    longitude_deg: hasLivePosition ? Number(livePosition.longitude_deg) : DEFAULT_MAP_CENTER.longitude_deg,
  }));

  useEffect(() => {
    if (!mapRef.current) {
      return undefined;
    }

    const observer = new ResizeObserver((entries) => {
      const rect = entries[0]?.contentRect;
      if (!rect) {
        return;
      }
      setSize({
        width: Math.max(320, rect.width),
        height: Math.max(360, rect.height),
      });
    });

    observer.observe(mapRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => () => {
    if (mapDragRafRef.current) {
      window.cancelAnimationFrame(mapDragRafRef.current);
      mapDragRafRef.current = null;
    }
  }, []);

  useEffect(() => {
    if (!hasLivePosition || !autoFollow) {
      return;
    }

    setCenter({
      latitude_deg: Number(livePosition.latitude_deg),
      longitude_deg: Number(livePosition.longitude_deg),
    });
  }, [autoFollow, hasLivePosition, livePosition.latitude_deg, livePosition.longitude_deg]);

  const centerWorld = useMemo(
    () => latLonToWorld(center.latitude_deg, center.longitude_deg, zoom),
    [center.latitude_deg, center.longitude_deg, zoom],
  );

  function projectCoordinate(latitude, longitude) {
    const world = latLonToWorld(latitude, longitude, zoom);
    return {
      x: world.x - centerWorld.x + size.width / 2,
      y: world.y - centerWorld.y + size.height / 2,
    };
  }

  const missionMarkers = useMemo(() => {
    const markers = [];
    let waypointOrder = 0;

    missionItems.forEach((item, index) => {
      if (item.type === "waypoint") {
        waypointOrder += 1;
      }

      const coordinate = getMissionMarkerCoordinate(item, index, missionItems, livePosition);
      if (!coordinate || !hasValidCoordinate(coordinate.latitude_deg, coordinate.longitude_deg)) {
        return;
      }

      const point = projectCoordinate(coordinate.latitude_deg, coordinate.longitude_deg);
      const altitudeM = getVisualAltitudeM(item, livePosition);
      markers.push({
        index,
        item,
        latitude_deg: coordinate.latitude_deg,
        longitude_deg: coordinate.longitude_deg,
        fromFallback: coordinate.fromFallback,
        fromDrone: coordinate.fromDrone,
        canDrag: itemCanUseMapCoordinate(item),
        waypointOrder: item.type === "waypoint" ? waypointOrder : null,
        altitudeM,
        altitudeLabel: formatAltitudeLabel(altitudeM),
        x: point.x,
        y: point.y,
      });
    });

    return markers;
  }, [centerWorld.x, centerWorld.y, livePosition.latitude_deg, livePosition.longitude_deg, missionItems, size.height, size.width, zoom]);

  const liveMarker = useMemo(() => {
    if (!hasLivePosition) {
      return null;
    }

    const point = projectCoordinate(livePosition.latitude_deg, livePosition.longitude_deg);
    return {
      x: point.x,
      y: point.y,
      headingDeg: Number.isFinite(Number(droneTelemetry.headingDeg)) ? Number(droneTelemetry.headingDeg) : 0,
      altitudeText: livePosition.relative_altitude_m != null
        ? `${Number(livePosition.relative_altitude_m).toFixed(1)} m AGL`
        : `${formatSmallNumber(livePosition.altitude_amsl_m, 1, " m")} AMSL`,
    };
  }, [centerWorld.x, centerWorld.y, droneTelemetry.headingDeg, hasLivePosition, livePosition.altitude_amsl_m, livePosition.latitude_deg, livePosition.longitude_deg, livePosition.relative_altitude_m, size.height, size.width, zoom]);

  const flightTrackMarkers = useMemo(() => {
    if (!Array.isArray(flightTrack) || flightTrack.length === 0) {
      return [];
    }
    return flightTrack
      .filter((point) => hasValidCoordinate(point.latitude_deg, point.longitude_deg))
      .map((point) => projectCoordinate(point.latitude_deg, point.longitude_deg));
  }, [centerWorld.x, centerWorld.y, flightTrack, size.height, size.width, zoom]);

  const tiles = useMemo(() => {
    const tileCount = 2 ** zoom;
    const visibleWorld = {
      left: centerWorld.x - size.width / 2,
      right: centerWorld.x + size.width / 2,
      top: centerWorld.y - size.height / 2,
      bottom: centerWorld.y + size.height / 2,
    };
    const minTileX = Math.floor(visibleWorld.left / TILE_SIZE) - 1;
    const maxTileX = Math.floor(visibleWorld.right / TILE_SIZE) + 1;
    const minTileY = Math.max(0, Math.floor(visibleWorld.top / TILE_SIZE) - 1);
    const maxTileY = Math.min(tileCount - 1, Math.floor(visibleWorld.bottom / TILE_SIZE) + 1);
    const nextTiles = [];

    for (let x = minTileX; x <= maxTileX; x += 1) {
      for (let y = minTileY; y <= maxTileY; y += 1) {
        const wrappedX = ((x % tileCount) + tileCount) % tileCount;
        nextTiles.push({
          key: `${zoom}-${wrappedX}-${y}-${x}`,
          url: `https://tile.openstreetmap.org/${zoom}/${wrappedX}/${y}.png`,
          left: x * TILE_SIZE - centerWorld.x + size.width / 2,
          top: y * TILE_SIZE - centerWorld.y + size.height / 2,
        });
      }
    }

    return nextTiles;
  }, [centerWorld.x, centerWorld.y, size.height, size.width, zoom]);

  function eventToCoordinate(event) {
    const rect = mapRef.current.getBoundingClientRect();
    const localX = event.clientX - rect.left;
    const localY = event.clientY - rect.top;
    return worldToLatLon(
      centerWorld.x - size.width / 2 + localX,
      centerWorld.y - size.height / 2 + localY,
      zoom,
    );
  }

  function handleMapClick(event) {
    if (!waypointPlacementMode) {
      return;
    }

    const coordinate = eventToCoordinate(event);
    const selectedItem = missionItems[selectedIndex];

    if (itemCanUseMapCoordinate(selectedItem)) {
      onUpdateWaypointFromMap(selectedIndex, coordinate.latitude_deg, coordinate.longitude_deg);
      return;
    }

    onAppendWaypointFromMap(coordinate.latitude_deg, coordinate.longitude_deg);
  }

  function handlePointerDown(event) {
    if (event.button !== 0 || markerDragRef.current) {
      return;
    }

    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      startWorld: centerWorld,
      moved: false,
    };
  }

  function handlePointerMove(event) {
    const markerDrag = markerDragRef.current;
    if (markerDrag && markerDrag.pointerId === event.pointerId) {
      handleMarkerPointerMove(event);
      return;
    }

    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) {
      return;
    }

    const dx = event.clientX - drag.startX;
    const dy = event.clientY - drag.startY;
    if (Math.abs(dx) + Math.abs(dy) > 4) {
      drag.moved = true;
    }

    if (drag.moved) {
      setAutoFollow(false);
      const nextCenter = worldToLatLon(drag.startWorld.x - dx, drag.startWorld.y - dy, zoom);
      if (!mapDragRafRef.current) {
        mapDragRafRef.current = window.requestAnimationFrame(() => {
          mapDragRafRef.current = null;
          setCenter(nextCenter);
        });
      }
    }
  }

  function handlePointerUp(event) {
    const markerDrag = markerDragRef.current;
    if (markerDrag && markerDrag.pointerId === event.pointerId) {
      handleMarkerPointerUp(event);
      return;
    }

    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) {
      return;
    }

    dragRef.current = null;
    if (!drag.moved) {
      setAutoFollow(false);
      handleMapClick(event);
    }
  }

  function handleZoomAt(delta, localX = size.width / 2, localY = size.height / 2) {
    const nextZoom = clamp(zoom + delta, MIN_MAP_ZOOM, MAX_MAP_ZOOM);
    if (nextZoom === zoom) {
      return;
    }

    const coordinateUnderCursor = worldToLatLon(
      centerWorld.x - size.width / 2 + localX,
      centerWorld.y - size.height / 2 + localY,
      zoom,
    );
    const worldAtNextZoom = latLonToWorld(coordinateUnderCursor.latitude_deg, coordinateUnderCursor.longitude_deg, nextZoom);
    const nextCenterWorld = {
      x: worldAtNextZoom.x - localX + size.width / 2,
      y: worldAtNextZoom.y - localY + size.height / 2,
    };

    setAutoFollow(false);
    setZoom(nextZoom);
    setCenter(worldToLatLon(nextCenterWorld.x, nextCenterWorld.y, nextZoom));
  }

  function handleWheel(event) {
    event.preventDefault();
    const now = performance.now();
    if (now - lastWheelZoomAtRef.current < 80) {
      return;
    }
    lastWheelZoomAtRef.current = now;
    const rect = mapRef.current.getBoundingClientRect();
    const localX = event.clientX - rect.left;
    const localY = event.clientY - rect.top;
    const delta = event.deltaY < 0 ? 1 : -1;
    handleZoomAt(delta, localX, localY);
  }

  function centerOnLivePosition() {
    if (!hasLivePosition) {
      return;
    }

    setCenter({
      latitude_deg: Number(livePosition.latitude_deg),
      longitude_deg: Number(livePosition.longitude_deg),
    });
    setAutoFollow(true);
  }

  function fitWaypoints() {
    const coordinates = missionMarkers
      .map((marker) => ({ latitude_deg: marker.latitude_deg, longitude_deg: marker.longitude_deg }))
      .filter(({ latitude_deg, longitude_deg }) => hasValidCoordinate(latitude_deg, longitude_deg));

    if (coordinates.length === 0) {
      centerOnLivePosition();
      return;
    }

    const latitudes = coordinates.map((coordinate) => coordinate.latitude_deg);
    const longitudes = coordinates.map((coordinate) => coordinate.longitude_deg);
    setAutoFollow(false);
    setCenter({
      latitude_deg: (Math.min(...latitudes) + Math.max(...latitudes)) / 2,
      longitude_deg: (Math.min(...longitudes) + Math.max(...longitudes)) / 2,
    });
  }

  function handleMarkerPointerDown(event, marker) {
    if (event.button !== 0) {
      return;
    }

    event.stopPropagation();
    setAutoFollow(false);
    onSelectItem(marker.index);

    if (!marker.canDrag) {
      return;
    }

    event.currentTarget.setPointerCapture(event.pointerId);
    markerDragRef.current = {
      pointerId: event.pointerId,
      index: marker.index,
      startX: event.clientX,
      startY: event.clientY,
      moved: false,
    };
  }

  function handleMarkerPointerMove(event) {
    const drag = markerDragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) {
      return;
    }

    event.stopPropagation();
    const dx = event.clientX - drag.startX;
    const dy = event.clientY - drag.startY;
    if (Math.abs(dx) + Math.abs(dy) > 2) {
      drag.moved = true;
    }

    if (drag.moved) {
      const coordinate = eventToCoordinate(event);
      onUpdateWaypointFromMap(drag.index, coordinate.latitude_deg, coordinate.longitude_deg, { silent: true });
    }
  }

  function handleMarkerPointerUp(event) {
    const drag = markerDragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) {
      return;
    }

    event.stopPropagation();
    markerDragRef.current = null;
    if (!drag.moved) {
      onSelectItem(drag.index);
    }
  }

  return (
    <div
      ref={mapRef}
      role="application"
      aria-label="Mission map planner"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onWheel={handleWheel}
      className="relative h-full w-full touch-none cursor-grab select-none overflow-hidden bg-[#111827] active:cursor-grabbing"
    >
      {tiles.map((tile) => (
        <img
          key={tile.key}
          src={tile.url}
          alt=""
          draggable="false"
          className="absolute max-w-none select-none opacity-95"
          loading="eager"
          decoding="async"
          style={{ transform: `translate3d(${tile.left}px, ${tile.top}px, 0)`, width: TILE_SIZE, height: TILE_SIZE, contain: "strict" }}
        />
      ))}

      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(9,9,11,0.02)_62%,rgba(9,9,11,0.18)_100%)]" />
      <div className="pointer-events-none absolute left-5 top-5 rounded-2xl border border-cyan-300/20 bg-zinc-950/72 px-3 py-2 text-[11px] font-black uppercase tracking-[0.16em] text-cyan-100 shadow-xl backdrop-blur-sm">2D map · Three.js 3D editor off-map</div>

      <svg className="pointer-events-none absolute inset-0 h-full w-full">
        {flightTrackMarkers.length > 1 ? (
          <polyline
            points={flightTrackMarkers.map((point) => `${point.x},${point.y}`).join(" ")}
            fill="none"
            stroke="rgba(16,185,129,0.82)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="4"
          />
        ) : null}
        {missionMarkers.length > 1 ? (
          <polyline
            points={missionMarkers.map((marker) => `${marker.x},${marker.y}`).join(" ")}
            fill="none"
            stroke="rgba(6,182,212,0.90)"
            strokeDasharray="10 9"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="4"
          />
        ) : null}
      </svg>

      {missionMarkers.map((marker) => {
        const isSelected = marker.index === selectedIndex;
        const itemLabel = marker.item.type === "waypoint" ? `WP${marker.waypointOrder}` : MISSION_LABEL[marker.item.type] ?? marker.item.type.toUpperCase();
        return (
          <button
            key={marker.index}
            type="button"
            onPointerDown={(event) => handleMarkerPointerDown(event, marker)}
            onPointerMove={handleMarkerPointerMove}
            onPointerUp={handleMarkerPointerUp}
            className={`absolute -translate-x-1/2 -translate-y-1/2 ${marker.canDrag ? "active:cursor-grabbing" : "cursor-pointer"}`}
            style={{ left: marker.x, top: marker.y, touchAction: "none" }}
            title={marker.canDrag ? `Kéo để đổi vị trí ${itemLabel} · Alt ${marker.altitudeLabel}` : "RTL đang neo tại vị trí drone hiện tại"}
          >
            <span className={`relative grid h-[54px] w-[54px] place-items-center rounded-2xl border shadow-[0_12px_30px_rgba(0,0,0,0.42)] transition hover:scale-110 ${
              isSelected
                ? `ring-4 ${MISSION_MARKER_STYLE[marker.item.type] ?? MISSION_MARKER_STYLE.waypoint}`
                : `${MISSION_MARKER_STYLE[marker.item.type] ?? MISSION_MARKER_STYLE.waypoint}`
            }`}>
              <Icon name={MISSION_ICON[marker.item.type] ?? "radio_button_checked"} className="relative text-[27px] leading-none drop-shadow" />
              <span className="absolute -bottom-6 rounded-full border border-zinc-950/20 bg-zinc-950/90 px-2 py-0.5 text-[10px] font-black text-white shadow-lg">
                {itemLabel}
              </span>
              {marker.fromFallback ? <span className="absolute -left-1 -top-1 h-3 w-3 rounded-full border border-zinc-950 bg-white" title={marker.fromDrone ? "RTL đang hiển thị tại vị trí drone hiện tại" : "Vị trí icon đang dùng tọa độ fallback"} /> : null}
            </span>
          </button>
        );
      })}

      {liveMarker ? (
        <div
          className="absolute -translate-x-1/2 -translate-y-1/2"
          style={{ left: liveMarker.x, top: liveMarker.y }}
          title={`Live UAV · heading ${liveMarker.headingDeg.toFixed(0)}° · ${liveMarker.altitudeText}`}
        >
          <div className="relative grid h-[70px] w-[70px] place-items-center rounded-full border border-emerald-100/80 bg-emerald-400/18 shadow-[0_0_48px_rgba(52,211,153,0.48)]">
            <div className="absolute h-[70px] w-[70px] rounded-full bg-emerald-400/10" />
            <div
              className="relative grid h-[46px] w-[46px] place-items-center rounded-2xl border border-emerald-100/60 bg-zinc-950/72 shadow-[0_14px_30px_rgba(0,0,0,0.45)]"
              style={{ transform: `rotate(${liveMarker.headingDeg}deg)` }}
            >
              <Icon name="navigation" className="relative text-[36px] text-emerald-50 drop-shadow" />
            </div>
            <span className="absolute -top-4 rounded-full border border-emerald-300/25 bg-zinc-950/88 px-2 py-1 font-mono text-[10px] font-black text-emerald-100 shadow-lg">
              {liveMarker.headingDeg.toFixed(0)}°
            </span>
          </div>
        </div>
      ) : null}

      <div className="pointer-events-auto absolute bottom-5 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-3xl border border-white/15 bg-zinc-950/82 p-2 shadow-[0_16px_45px_rgba(0,0,0,0.40)] backdrop-blur-sm">
        <MiniIconButton icon="add" label="Zoom in" onClick={() => handleZoomAt(1)} />
        <MiniIconButton icon="remove" label="Zoom out" onClick={() => handleZoomAt(-1)} />
        <GlassButton icon="my_location" label="Center" tone="emerald" disabled={!hasLivePosition} onClick={centerOnLivePosition} />
        <GlassButton icon="route" label="Fit" tone="cyan" onClick={fitWaypoints} />
        <GlassButton
          icon={waypointPlacementMode ? "edit_location_alt" : "location_off"}
          label={waypointPlacementMode ? "Set WP: ON" : "Set WP"}
          tone={waypointPlacementMode ? "amber" : "zinc"}
          onClick={onToggleWaypointPlacement}
        />
        <GlassButton icon="view_in_ar" label="3D" tone="cyan" onClick={onOpenThreeEditor} />
        <MiniIconButton icon="delete_sweep" label="Clear flown path" onClick={onClearFlightTrack} />
      </div>
    </div>
  );
}, (previous, next) => (
  previous.status === next.status
  && previous.missionItems === next.missionItems
  && previous.selectedIndex === next.selectedIndex
  && previous.waypointPlacementMode === next.waypointPlacementMode
  && previous.flightTrack === next.flightTrack
));

function MissionItemRow({
  item,
  index,
  expanded,
  dragOver,
  compactInputClass,
  onSelect,
  onChange,
  onRemove,
  onApplyLivePosition,
  onDragStart,
  onDragOver,
  onDrop,
  onDragEnd,
}) {
  const hasMapCoordinate = itemCanUseMapCoordinate(item);
  const isHold = item.type === "hold";
  const isTakeoff = item.type === "takeoff";
  const isRtl = item.type === "rtl";

  return (
    <div
      draggable
      onDragStart={(event) => onDragStart(event, index)}
      onDragOver={(event) => onDragOver(event, index)}
      onDrop={(event) => onDrop(event, index)}
      onDragEnd={onDragEnd}
      className={`overflow-hidden rounded-3xl border transition ${
        expanded
          ? "border-cyan-300/60 bg-cyan-400/[0.10] shadow-[0_18px_45px_rgba(34,211,238,0.10)]"
          : dragOver
            ? "border-amber-300/70 bg-amber-400/[0.10]"
            : "border-white/10 bg-zinc-950/62 hover:bg-white/[0.08]"
      }`}
    >
      <button type="button" onClick={() => onSelect(index)} className="w-full px-3 py-3 text-left">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 shrink-0 cursor-grab place-items-center rounded-2xl border border-white/10 bg-white/8 text-zinc-300" title="Kéo thả để đổi thứ tự">
            <Icon name={MISSION_ICON[item.type] ?? "radio_button_checked"} className="text-[23px]" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between gap-3">
              <strong className="truncate text-sm text-zinc-100">{item.name || item.type}</strong>
              <span className="rounded-full bg-white/8 px-2 py-1 text-[10px] font-black text-zinc-300">#{index + 1}</span>
            </div>
            <div className="mt-1 flex items-center gap-2 text-[11px] text-zinc-500">
              <Icon name="drag_indicator" className="text-[16px]" />
              <span>{item.type.toUpperCase()}</span>
              {hasMapCoordinate ? <span className="truncate">· {formatCoordinate(item.latitude_deg)}, {formatCoordinate(item.longitude_deg)}</span> : null}
              {isTakeoff ? <span className="truncate">· target {formatAltitudeLabel(item.altitude_m)} AGL</span> : null}
            </div>
          </div>
          <Icon name="keyboard_arrow_down" className={`text-[26px] text-zinc-400 transition ${expanded ? "rotate-180" : ""}`} />
        </div>
      </button>

      {expanded ? (
        <div className="grid gap-3 border-t border-white/10 px-3 pb-4 pt-3">
          <div className="grid grid-cols-[1fr_auto] gap-2">
            <Field label="Name">
              <input value={item.name} onChange={(event) => onChange(index, "name", event.target.value)} className={compactInputClass} />
            </Field>
            <button
              type="button"
              onClick={() => onRemove(index)}
              className="mt-[22px] grid h-[42px] w-[42px] place-items-center rounded-2xl border border-rose-300/30 bg-rose-400/10 text-rose-100 transition hover:bg-rose-400/20"
              title="Remove"
            >
              <Icon name="delete" className="text-[21px]" />
            </button>
          </div>

          {isTakeoff ? (
            <>
              <Field label="Target Altitude (m AGL)">
                <input value={item.altitude_m} onChange={(event) => onChange(index, "altitude_m", event.target.value)} className={compactInputClass} />
              </Field>
              <div className="rounded-2xl border border-emerald-300/20 bg-emerald-400/10 px-3 py-3 text-xs font-semibold text-emerald-100">
                Takeoff chỉ dùng độ cao tương đối. Node sẽ tự cộng với AMSL hiện tại của drone trước khi gửi lệnh takeoff sang PX4.
              </div>
            </>
          ) : hasMapCoordinate ? (
            <>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Lat">
                  <input value={item.latitude_deg} onChange={(event) => onChange(index, "latitude_deg", event.target.value)} className={compactInputClass} />
                </Field>
                <Field label="Lon">
                  <input value={item.longitude_deg} onChange={(event) => onChange(index, "longitude_deg", event.target.value)} className={compactInputClass} />
                </Field>
              </div>
              <Field label="Alt AMSL (m)">
                <input value={item.altitude_m} onChange={(event) => onChange(index, "altitude_m", event.target.value)} className={compactInputClass} />
              </Field>
              <div className="grid grid-cols-2 gap-2">
                <GlassButton icon="my_location" label="Use UAV" tone="cyan" onClick={() => onApplyLivePosition(index)} />
                <GlassButton icon="open_with" label="Drag on map" tone="amber" onClick={() => onSelect(index)} />
              </div>
            </>
          ) : isRtl ? (
            <div className="rounded-2xl border border-rose-300/20 bg-rose-400/10 px-3 py-3 text-xs font-semibold text-rose-100">
              RTL không cần nhập tọa độ. Icon RTL được neo ngay tại vị trí drone hiện tại; nếu chưa có GPS live thì mới fallback về tọa độ đầu mission.
            </div>
          ) : (
            <div className="rounded-2xl border border-white/10 bg-white/5 px-3 py-3 text-xs font-semibold text-zinc-300">
              Item này không cần tham số bổ sung.
            </div>
          )}

          {isHold ? (
            <Field label="Hold Time (s)">
              <input value={item.hold_time_s} onChange={(event) => onChange(index, "hold_time_s", event.target.value)} className={compactInputClass} />
            </Field>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

function MissionPanel({
  open,
  busyAction,
  missionName,
  setMissionName,
  defaults,
  setDefaults,
  missionItems,
  waypointCount,
  selectedMissionIndex,
  waypointPlacementMode,
  dragOverIndex,
  draggedIndex,
  compactInputClass,
  livePositionForStatus,
  onClose,
  onToggleWaypointPlacement,
  onSave,
  onActivate,
  onRun,
  onAppendItem,
  onAppendWaypointFromMap,
  onUpdateMissionItem,
  onRemoveMissionItem,
  onApplyLivePosition,
  onSelectMissionIndex,
  onItemDragStart,
  onItemDragOver,
  onItemDrop,
  onItemDragEnd,
  missionRuntime,
}) {
  if (!open) {
    return (
      <div className="pointer-events-auto absolute left-4 top-4 z-40">
        <MiniIconButton icon="route" label="Open mission planner" onClick={onClose} />
      </div>
    );
  }

  return (
    <aside className="pointer-events-auto absolute bottom-4 left-4 top-4 z-40 flex w-[420px] max-w-[calc(100vw-2rem)] flex-col overflow-hidden rounded-[34px] border border-white/15 bg-zinc-950/[0.84] shadow-[0_28px_85px_rgba(0,0,0,0.55)] backdrop-blur-sm">
      <div className="border-b border-white/10 p-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-3xl bg-cyan-400/15 text-cyan-100">
              <Icon name="route" className="text-[28px]" />
            </div>
            <div className="min-w-0">
              <h1 className="truncate text-lg font-black tracking-[-0.04em] text-zinc-50">Mission</h1>
              <p className="text-xs text-zinc-400">{missionItems.length} steps · {waypointCount} WP</p>
            </div>
          </div>
          <MiniIconButton icon="keyboard_double_arrow_left" label="Collapse" onClick={onClose} />
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2">
          <GlassButton icon="save" label={busyAction === "save" ? "Saving" : "Save"} tone="cyan" disabled={busyAction !== "" || missionItems.length === 0} onClick={onSave} />
          <GlassButton icon="play_arrow" label={busyAction === "activate" ? "Sending" : "Start"} tone="amber" disabled={busyAction !== ""} onClick={onActivate} />
          <GlassButton icon="rocket_launch" label={busyAction === "run" ? "Run" : "Save+Run"} tone="emerald" disabled={busyAction !== "" || missionItems.length === 0} onClick={onRun} />
        </div>
        <button
          type="button"
          onPointerDown={(event) => event.stopPropagation()}
          onClick={(event) => {
            event.stopPropagation();
            onToggleWaypointPlacement();
          }}
          className={`mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border px-3 py-3 text-sm font-black transition ${
            waypointPlacementMode
              ? "border-amber-300/60 bg-amber-400/16 text-amber-50 shadow-[0_0_28px_rgba(251,191,36,0.14)]"
              : "border-white/10 bg-white/[0.06] text-zinc-200 hover:bg-white/[0.10]"
          }`}
        >
          <Icon name={waypointPlacementMode ? "edit_location_alt" : "add_location_alt"} className="text-[22px]" />
          {waypointPlacementMode ? "Đang bật đặt waypoint trên map" : "Bật chế độ đặt waypoint"}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="grid gap-3">
          <section className="rounded-[26px] border border-white/10 bg-white/[0.045] p-3">
            <div className="mb-3 grid grid-cols-2 gap-2 text-xs">
              <div className="rounded-2xl border border-white/10 bg-zinc-950/55 px-3 py-2">
                <p className="text-zinc-500">Runtime</p>
                <p className="mt-1 font-bold text-zinc-100">{missionRuntime.runtime_state ?? "--"}</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-zinc-950/55 px-3 py-2">
                <p className="text-zinc-500">Mission Active</p>
                <p className="mt-1 font-bold text-zinc-100">{missionRuntime.mission_active ? "YES" : "NO"}</p>
              </div>
            </div>

            <Field label="Mission Name">
              <input value={missionName} onChange={(event) => setMissionName(event.target.value)} className={compactInputClass} />
            </Field>
            <div className="mt-3 grid grid-cols-3 gap-2">
              <Field label="H Vel">
                <input value={defaults.horizontal_velocity_m_s} onChange={(event) => setDefaults((previous) => ({ ...previous, horizontal_velocity_m_s: event.target.value }))} className={compactInputClass} />
              </Field>
              <Field label="V Vel">
                <input value={defaults.vertical_velocity_m_s} onChange={(event) => setDefaults((previous) => ({ ...previous, vertical_velocity_m_s: event.target.value }))} className={compactInputClass} />
              </Field>
              <Field label="Yaw">
                <input value={defaults.max_heading_rate_deg_s} onChange={(event) => setDefaults((previous) => ({ ...previous, max_heading_rate_deg_s: event.target.value }))} className={compactInputClass} />
              </Field>
            </div>
          </section>

          <section className="rounded-[26px] border border-white/10 bg-white/[0.045] p-3">
            <div className="grid grid-cols-5 gap-2">
              {[
                ["takeoff", "flight_takeoff", "TO"],
                ["waypoint", "add_location_alt", "WP"],
                ["hold", "pause_circle", "Hold"],
                ["land", "flight_land", "Land"],
                ["rtl", "home_pin", "RTL"],
              ].map(([type, icon, label]) => (
                <button key={type} type="button" onClick={() => onAppendItem(type)} className="grid gap-1 rounded-2xl border border-white/10 bg-zinc-900/70 px-2 py-3 text-center text-[11px] font-black text-zinc-200 transition hover:border-cyan-300/40 hover:bg-cyan-400/10">
                  <Icon name={icon} className="mx-auto text-[22px]" />
                  {label}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => onAppendWaypointFromMap(livePositionForStatus.latitude_deg, livePositionForStatus.longitude_deg)}
              disabled={!hasValidCoordinate(livePositionForStatus.latitude_deg, livePositionForStatus.longitude_deg)}
              className="mt-2 flex w-full items-center justify-center gap-2 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 px-3 py-3 text-sm font-bold text-emerald-100 transition hover:bg-emerald-400/20 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Icon name="my_location" className="text-[20px]" />
              WP tại UAV
            </button>
          </section>

          <section className="grid gap-2">
            {missionItems.length === 0 ? (
              <div className="rounded-[26px] border border-dashed border-white/15 bg-zinc-950/45 px-4 py-6 text-center">
                <p className="text-sm font-bold text-zinc-100">Chưa có mission local trên UI</p>
                <p className="mt-2 text-xs leading-6 text-zinc-500">
                  Thêm step bằng các nút phía trên hoặc đặt waypoint trực tiếp trên map.
                </p>
              </div>
            ) : (
              missionItems.map((item, index) => (
                <MissionItemRow
                  key={`${item.type}-${index}`}
                  item={item}
                  index={index}
                  expanded={selectedMissionIndex === index}
                  dragOver={dragOverIndex === index && draggedIndex !== index}
                  compactInputClass={compactInputClass}
                  onSelect={onSelectMissionIndex}
                  onChange={onUpdateMissionItem}
                  onRemove={onRemoveMissionItem}
                  onApplyLivePosition={onApplyLivePosition}
                  onDragStart={onItemDragStart}
                  onDragOver={onItemDragOver}
                  onDrop={onItemDrop}
                  onDragEnd={onItemDragEnd}
                />
              ))
            )}
          </section>
        </div>
      </div>
    </aside>
  );
}

function DroneStatCard({ icon, value, caption, tone = "zinc" }) {
  const toneMap = {
    zinc: "bg-white/[0.055] text-zinc-100",
    emerald: "bg-emerald-400/12 text-emerald-50",
    cyan: "bg-cyan-400/12 text-cyan-50",
    amber: "bg-amber-400/12 text-amber-50",
    rose: "bg-rose-400/12 text-rose-50",
  };

  return (
    <div className={`rounded-[24px] border border-white/10 p-3 ${toneMap[tone]}`}>
      <div className="flex items-center gap-3">
        <div className="grid h-11 w-11 place-items-center rounded-2xl bg-zinc-950/42">
          <Icon name={icon} className="text-[25px]" />
        </div>
        <div className="min-w-0">
          <p className="truncate text-base font-black tracking-[-0.03em]">{value}</p>
          <p className="truncate text-[11px] font-semibold text-zinc-400">{caption}</p>
        </div>
      </div>
    </div>
  );
}

function DroneStatusPanel({
  open,
  loading,
  status,
  drone,
  droneOptions,
  selectedDroneId,
  setSelectedDroneId,
  livePositionForStatus,
  logs,
  onClose,
}) {
  const topMessageCounts = Object.entries(drone.messageCounts)
    .sort((a, b) => Number(b[1]) - Number(a[1]))
    .slice(0, 8);

  if (!open) {
    return (
      <div className="pointer-events-auto absolute right-4 top-4 z-40 grid gap-2">
        <MiniIconButton icon="sensors" label="Open drone status" onClick={onClose} />
        <div className={`grid h-11 w-11 place-items-center rounded-2xl border border-white/10 ${drone.connected ? "bg-emerald-400/20 text-emerald-50" : "bg-rose-400/20 text-rose-50"}`}>
          <Icon name={drone.connected ? "link" : "link_off"} className="text-[22px]" />
        </div>
      </div>
    );
  }

  const connectionTone = drone.connected ? "emerald" : "rose";
  const batteryTone = Number(drone.batteryPercent) > 30 ? "emerald" : "amber";

  return (
    <aside className="pointer-events-auto absolute bottom-4 right-4 top-4 z-40 flex w-[380px] max-w-[calc(100vw-2rem)] flex-col overflow-hidden rounded-[34px] border border-white/15 bg-zinc-950/[0.84] shadow-[0_28px_85px_rgba(0,0,0,0.55)] backdrop-blur-sm">
      <div className="border-b border-white/10 p-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-3">
            <div className={`grid h-12 w-12 place-items-center rounded-3xl ${drone.connected ? "bg-emerald-400/15 text-emerald-100" : "bg-rose-400/15 text-rose-100"}`}>
              <Icon name="flight" className="text-[29px]" />
            </div>
            <div className="min-w-0">
              <h2 className="truncate text-lg font-black tracking-[-0.04em] text-zinc-50">{drone.armed ? "ARMED" : "DISARMED"}</h2>
              <p className="text-xs text-zinc-400">{loading ? "Polling..." : drone.connected ? "MAVLink live" : "MAVLink stale"}</p>
            </div>
          </div>
          <MiniIconButton icon="keyboard_double_arrow_right" label="Collapse" onClick={onClose} />
        </div>

        <div className="mt-4 rounded-[24px] border border-white/10 bg-white/[0.04] p-2">
          <div className="mb-2 flex items-center gap-2 px-2 text-[11px] font-black uppercase tracking-[0.16em] text-zinc-500">
            <Icon name="groups" className="text-[17px]" />
            Drone list
          </div>
          <div className="grid gap-2">
            {droneOptions.map((option) => (
              <button
                type="button"
                key={option.id}
                onClick={() => setSelectedDroneId(option.id)}
                className={`flex items-center gap-3 rounded-2xl border px-3 py-2 text-left transition ${
                  selectedDroneId === option.id
                    ? "border-cyan-300/60 bg-cyan-400/12"
                    : "border-white/10 bg-zinc-950/45 hover:bg-white/[0.08]"
                }`}
              >
                <div className={`grid h-9 w-9 place-items-center rounded-xl ${option.connected ? "bg-emerald-400/16 text-emerald-100" : "bg-zinc-800 text-zinc-400"}`}>
                  <Icon name="flight" className="text-[20px]" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <strong className="truncate text-sm text-zinc-100">{option.name}</strong>
                    <span className={`shrink-0 rounded-full px-2 py-0.5 text-[9px] font-black ${option.connected ? "bg-emerald-400/15 text-emerald-100" : "bg-zinc-700/70 text-zinc-300"}`}>
                      {option.connected ? "LIVE" : "STALE"}
                    </span>
                  </div>
                  <p className="mt-0.5 truncate text-[11px] text-zinc-500">{option.mode} · {option.batteryPercent ?? "--"}%</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="grid grid-cols-2 gap-3">
          <DroneStatCard icon="link" value={drone.connected ? "LIVE" : "STALE"} caption="Connection" tone={connectionTone} />
          <DroneStatCard icon="mode_standby" value={drone.mode} caption="Mode" tone="cyan" />
          <DroneStatCard icon="battery_full" value={drone.batteryPercent == null ? "--" : `${drone.batteryPercent}%`} caption={formatSmallNumber(drone.voltage, 2, " V")} tone={batteryTone} />
          <DroneStatCard icon="warning" value={drone.failsafe ? "YES" : "NO"} caption="Failsafe" tone={drone.failsafe ? "rose" : "emerald"} />
        </div>

        <div className="mt-3 grid grid-cols-2 gap-3">
          <DroneStatCard icon="explore" value={drone.headingDeg == null ? "--" : `${Number(drone.headingDeg).toFixed(0)}°`} caption="Heading" tone="cyan" />
          <DroneStatCard icon="height" value={formatSmallNumber(livePositionForStatus.relative_altitude_m ?? livePositionForStatus.altitude_amsl_m, 2, " m")} caption="Altitude" tone="zinc" />
          <DroneStatCard icon="schedule" value={formatAge(drone.heartbeatAge)} caption="Heartbeat" tone="zinc" />
        </div>

        <section className="mt-3 rounded-[26px] border border-white/10 bg-white/[0.045] p-4">
          <div className="flex items-center gap-3">
            <Icon name="gps_fixed" className="text-[24px] text-emerald-100" />
            <div>
              <h3 className="text-sm font-black text-zinc-100">GPS</h3>
              <p className="text-xs text-zinc-500">{livePositionForStatus.source}</p>
            </div>
          </div>
          <div className="mt-3 grid gap-2 font-mono text-sm text-zinc-100">
            <div className="flex justify-between gap-3"><span className="text-zinc-500">Lat</span><span>{formatCoordinate(livePositionForStatus.latitude_deg)}</span></div>
            <div className="flex justify-between gap-3"><span className="text-zinc-500">Lon</span><span>{formatCoordinate(livePositionForStatus.longitude_deg)}</span></div>
            <div className="flex justify-between gap-3"><span className="text-zinc-500">AMSL</span><span>{formatSmallNumber(livePositionForStatus.altitude_amsl_m, 2, " m")}</span></div>
          </div>
        </section>

        <section className="mt-3 rounded-[26px] border border-white/10 bg-white/[0.045] p-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Icon name="settings_input_antenna" className="text-[24px] text-cyan-100" />
              <h3 className="text-sm font-black text-zinc-100">MAVLink</h3>
            </div>
            <span className="rounded-full bg-white/8 px-2 py-1 text-[11px] text-zinc-400">{drone.id}</span>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2 text-center">
            <div className="rounded-2xl bg-zinc-950/55 p-2"><p className="text-xs text-zinc-500">Base</p><strong>{drone.baseMode ?? "--"}</strong></div>
            <div className="rounded-2xl bg-zinc-950/55 p-2"><p className="text-xs text-zinc-500">Custom</p><strong>{drone.customMode ?? "--"}</strong></div>
            <div className="rounded-2xl bg-zinc-950/55 p-2"><p className="text-xs text-zinc-500">Sys</p><strong>{drone.systemStatus ?? "--"}</strong></div>
          </div>
          <div className="mt-3 inline-flex items-center gap-2 rounded-full border border-white/10 bg-zinc-950/45 px-3 py-1.5 text-[11px] font-bold text-zinc-300">
            <Icon name="settings_ethernet" className="text-[16px]" />
            {formatLinkSummary(drone.connectionUrl)}
          </div>
        </section>

        <section className="mt-3 rounded-[26px] border border-white/10 bg-white/[0.045] p-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Icon name="topic" className="text-[23px] text-amber-100" />
              <div>
                <h3 className="text-sm font-black text-zinc-100">Mission Bridge</h3>
                <p className="text-xs text-zinc-500">{status.mission_runtime?.available ? "ROS mission runtime live" : "Waiting mission runtime status"}</p>
              </div>
            </div>
            <span className={`rounded-full px-2 py-1 text-[10px] font-black ${status.mission_runtime?.mission_active ? "bg-emerald-400/12 text-emerald-100" : "bg-zinc-700/70 text-zinc-300"}`}>
              {status.mission_runtime?.runtime_state ?? "--"}
            </span>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
            <div className="rounded-2xl bg-zinc-950/55 p-2"><p className="text-zinc-500">Ready</p><strong>{status.mission_runtime?.mission_ready ? "YES" : "NO"}</strong></div>
            <div className="rounded-2xl bg-zinc-950/55 p-2"><p className="text-zinc-500">Start</p><strong>{status.mission_runtime?.mission_start_in_progress ? "PENDING" : "IDLE"}</strong></div>
            <div className="rounded-2xl bg-zinc-950/55 p-2"><p className="text-zinc-500">Step</p><strong>{status.mission_runtime?.current_item_index ?? "--"}</strong></div>
            <div className="rounded-2xl bg-zinc-950/55 p-2"><p className="text-zinc-500">Alt Offset</p><strong>{formatSmallNumber(status.mission_runtime?.altitude_offset_m, 2, " m")}</strong></div>
          </div>
          <div className="mt-3 rounded-2xl border border-white/10 bg-zinc-950/55 px-3 py-3 text-xs">
            <p className="text-zinc-500">BT branch</p>
            <p className="mt-1 font-semibold text-zinc-100">{status.mission_runtime?.active_bt_branch ?? "--"}</p>
            {status.mission_runtime?.last_error ? <p className="mt-2 text-rose-200">{status.mission_runtime.last_error}</p> : null}
          </div>
        </section>

        <section className="mt-3 rounded-[26px] border border-white/10 bg-white/[0.045] p-4">
          <div className="mb-3 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Icon name="dns" className="text-[23px] text-zinc-200" />
              <h3 className="text-sm font-black text-zinc-100">Messages</h3>
            </div>
            <span className="text-xs text-zinc-500">top {topMessageCounts.length}</span>
          </div>
          <div className="grid max-h-[155px] gap-1.5 overflow-y-auto pr-1 font-mono text-[11px]">
            {topMessageCounts.length === 0 ? (
              <p className="text-sm text-zinc-500">No messages.</p>
            ) : (
              topMessageCounts.map(([name, count]) => (
                <div key={name} className="flex justify-between gap-3 rounded-2xl border border-white/10 bg-zinc-950/50 px-3 py-2">
                  <span className="truncate text-zinc-400">{name}</span>
                  <span className="text-zinc-100">{count}</span>
                </div>
              ))
            )}
          </div>
        </section>

        <section className="mt-3 rounded-[26px] border border-white/10 bg-white/[0.045] p-4">
          <div className="mb-3 flex items-center gap-3">
            <Icon name="history" className="text-[23px] text-zinc-200" />
            <h3 className="text-sm font-black text-zinc-100">Log</h3>
          </div>
          <div className="grid max-h-[180px] gap-2 overflow-y-auto pr-1">
            {drone.lastError ? <div className="rounded-2xl border border-rose-400/25 bg-rose-400/10 p-3 text-xs text-rose-100">{drone.lastError}</div> : null}
            {drone.lastStatustext ? <div className="rounded-2xl border border-amber-400/25 bg-amber-400/10 p-3 text-xs text-amber-100">{drone.lastStatustext}</div> : null}
            {logs.length === 0 ? (
              <p className="text-sm text-zinc-500">No action yet.</p>
            ) : (
              logs.map((entry) => (
                <div key={entry.id} className="rounded-2xl border border-white/10 bg-zinc-950/55 p-3">
                  <div className="flex items-center justify-between gap-3">
                    <strong className="truncate text-sm text-zinc-100">{entry.title}</strong>
                    <span className="font-mono text-[10px] text-zinc-500">{entry.timestamp}</span>
                  </div>
                  <p className="mt-2 text-xs leading-5 text-zinc-400">{entry.detail}</p>
                </div>
              ))
            )}
          </div>
        </section>
      </div>
    </aside>
  );
}


const ThreeWaypointEditor = lazy(() => import("./ThreeWaypointEditor.jsx"));

function ThreeEditorFallback() {
  return (
    <div className="pointer-events-auto absolute bottom-24 left-1/2 z-[60] -translate-x-1/2 rounded-3xl border border-cyan-300/25 bg-zinc-950/88 px-5 py-4 text-sm font-bold text-cyan-100 shadow-xl">
      Đang tải Three.js editor...
    </div>
  );
}

export default function App() {
  const [status, setStatus] = useState(EMPTY_STATUS);
  const [missionName, setMissionName] = useState("adaptive-run");
  const [defaults, setDefaults] = useState(DEFAULT_DEFAULTS);
  const [missionItems, setMissionItems] = useState([]);
  const [busyAction, setBusyAction] = useState("");
  const [loading, setLoading] = useState(true);
  const [logs, setLogs] = useState([]);
  const [selectedMissionIndex, setSelectedMissionIndex] = useState(null);
  const [draggedIndex, setDraggedIndex] = useState(null);
  const [dragOverIndex, setDragOverIndex] = useState(null);
  const [missionPanelOpen, setMissionPanelOpen] = useState(true);
  const [dronePanelOpen, setDronePanelOpen] = useState(true);
  const [selectedDroneId, setSelectedDroneId] = useState("1:1");
  const [waypointPlacementMode, setWaypointPlacementMode] = useState(false);
  const [threeEditorOpen, setThreeEditorOpen] = useState(false);
  const [flightTrack, setFlightTrack] = useState([]);

  useEffect(() => {
    let active = true;

    async function refreshStatus() {
      try {
        const snapshot = await request("/api/status");
        try {
          if (!snapshot.mavlink) {
            snapshot.mavlink = await request("/api/mavlink/status");
          }
        } catch {
          // Backend ROS-only vẫn chạy bình thường.
        }
        if (!active) {
          return;
        }
        setStatus(snapshot);
      } catch (error) {
        if (active) {
          pushLog("error", "Status poll failed", error.message);
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    }

    refreshStatus();
    const timer = window.setInterval(refreshStatus, 1000);
    return () => {
      active = false;
      window.clearInterval(timer);
    };
  }, []);

  useEffect(() => {
    const position = getLivePosition(status);

    // Chỉ ghi vệt bay khi UAV đang ARM. Khi DISARMED thì xoá trail để tránh xuất hiện
    // đường thẳng giả từ các mẫu GPS cũ / nhảy nguồn ROS-MAVLink.
    if (!isDroneArmed(status)) {
      setFlightTrack((previous) => (previous.length > 0 ? [] : previous));
      return;
    }

    if (!hasValidCoordinate(position.latitude_deg, position.longitude_deg)) {
      return;
    }

    setFlightTrack((previous) => {
      const nextPoint = {
        latitude_deg: Number(position.latitude_deg),
        longitude_deg: Number(position.longitude_deg),
        altitude_amsl_m: normalizeNumber(position.altitude_amsl_m),
        relative_altitude_m: normalizeNumber(position.relative_altitude_m),
        timestamp: Date.now(),
      };
      const lastPoint = previous[previous.length - 1];
      if (lastPoint) {
        const movedMeters = haversineDistanceMeters(lastPoint, nextPoint);
        const elapsed = nextPoint.timestamp - lastPoint.timestamp;

        // Nếu GPS/source bị nhảy xa bất thường thì reset trail, không nối thành đường dài qua bản đồ.
        if (movedMeters > MAX_FLIGHT_TRACK_JUMP_M && elapsed < 10000) {
          return [nextPoint];
        }

        if (movedMeters < 0.35 && elapsed < 4500) {
          return previous;
        }
      }
      return [...previous, nextPoint].slice(-450);
    });
  }, [status]);

  function pushLog(level, title, detail) {
    setLogs((previous) => [
      {
        id: crypto.randomUUID(),
        level,
        title,
        detail,
        timestamp: new Date().toLocaleTimeString(),
      },
      ...previous,
    ].slice(0, 12));
  }

  const payload = useMemo(
    () => missionPayload(missionName, defaults, missionItems),
    [missionName, defaults, missionItems],
  );

  async function runAction(key, action, successTitle) {
    setBusyAction(key);
    try {
      const response = await action();
      pushLog("success", successTitle, response.detail);
      const snapshot = await request("/api/status");
      setStatus(snapshot);
    } catch (error) {
      pushLog("error", `${successTitle} failed`, error.message);
    } finally {
      setBusyAction("");
    }
  }

  function updateMissionItem(index, field, value) {
    setMissionItems((previous) => previous.map((item, itemIndex) => (itemIndex === index ? { ...item, [field]: value } : item)));
  }

  function appendMissionItem(type) {
    setMissionItems((previous) => {
      const next = [...previous, createMissionItem(type, status, previous)];
      setSelectedMissionIndex(next.length - 1);
      setMissionPanelOpen(true);
      return next;
    });
  }

  function appendWaypointFromMap(latitude, longitude) {
    if (!hasValidCoordinate(latitude, longitude)) {
      pushLog("warn", "Không có tọa độ map hợp lệ", "Không thể thêm waypoint vì lat/lon không hợp lệ.");
      return;
    }

    setMissionItems((previous) => {
      const takeoffAltitude = getTakeoffAltitude(previous, status);
      const nextWaypoint = {
        type: "waypoint",
        name: `Waypoint ${previous.filter((item) => item.type === "waypoint").length + 1}`,
        latitude_deg: Number(latitude),
        longitude_deg: Number(longitude),
        altitude_m: takeoffAltitude,
        hold_time_s: 0,
      };
      const next = [...previous, nextWaypoint];
      setSelectedMissionIndex(next.length - 1);
      setMissionPanelOpen(true);
      return next;
    });
    pushLog("success", "Waypoint added", `${Number(latitude).toFixed(7)}, ${Number(longitude).toFixed(7)}`);
  }

  function updateWaypointFromMap(index, latitude, longitude, options = {}) {
    if (!hasValidCoordinate(latitude, longitude)) {
      return;
    }

    setMissionItems((previous) =>
      previous.map((item, itemIndex) =>
        itemIndex === index
          ? {
              ...item,
              latitude_deg: Number(latitude),
              longitude_deg: Number(longitude),
            }
          : item,
      ),
    );

    if (!options.silent) {
      pushLog("success", "Mission item updated", `Step ${index + 1}: ${Number(latitude).toFixed(7)}, ${Number(longitude).toFixed(7)}`);
    }
  }

  function removeMissionItem(index) {
    setMissionItems((previous) => previous.filter((_, itemIndex) => itemIndex !== index));
    setSelectedMissionIndex((previous) => {
      if (previous == null) {
        return null;
      }
      if (previous === index) {
        const nextIndex = index - 1;
        return nextIndex >= 0 ? nextIndex : null;
      }
      return previous > index ? previous - 1 : previous;
    });
  }

  function applyLivePosition(index) {
    const position = getLivePosition(status);
    if (!hasValidCoordinate(position.latitude_deg, position.longitude_deg)) {
      pushLog("warn", "No live position", "Backend chưa có global position hợp lệ từ MAVLink/ROS.");
      return;
    }

    setMissionItems((previous) =>
      previous.map((item, itemIndex) =>
        itemIndex === index
          ? {
              ...item,
              latitude_deg: position.latitude_deg,
              longitude_deg: position.longitude_deg,
              altitude_m: getTakeoffAltitude(previous, status),
            }
          : item,
      ),
    );
  }

  function reorderMissionItem(fromIndex, toIndex) {
    if (fromIndex === toIndex || fromIndex == null || toIndex == null) {
      return;
    }

    setMissionItems((previous) => {
      const next = [...previous];
      const [moved] = next.splice(fromIndex, 1);
      next.splice(toIndex, 0, moved);
      return next;
    });

    setSelectedMissionIndex(toIndex);
  }

  function handleItemDragStart(event, index) {
    setDraggedIndex(index);
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData("text/plain", String(index));
  }

  function handleItemDragOver(event, index) {
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
    setDragOverIndex(index);
  }

  function handleItemDrop(event, index) {
    event.preventDefault();
    const fromIndex = Number(event.dataTransfer.getData("text/plain"));
    reorderMissionItem(Number.isFinite(fromIndex) ? fromIndex : draggedIndex, index);
    setDraggedIndex(null);
    setDragOverIndex(null);
  }

  function handleItemDragEnd() {
    setDraggedIndex(null);
    setDragOverIndex(null);
  }

  const drone = getDroneTelemetry(status);
  const livePositionForStatus = getLivePosition(status);
  const mapStatus = useMemo(() => ({
    vehicle: {
      position: status?.vehicle?.position ?? {},
    },
    mavlink: {
      connected: Boolean(status?.mavlink?.connected),
      latitude_deg: status?.mavlink?.latitude_deg ?? null,
      longitude_deg: status?.mavlink?.longitude_deg ?? null,
      altitude_amsl_m: status?.mavlink?.altitude_amsl_m ?? null,
      relative_altitude_m: status?.mavlink?.relative_altitude_m ?? null,
      heading_deg: status?.mavlink?.heading_deg ?? null,
      yaw_deg: status?.mavlink?.yaw_deg ?? null,
    },
  }), [
    status?.vehicle?.position?.latitude_deg,
    status?.vehicle?.position?.longitude_deg,
    status?.vehicle?.position?.altitude_amsl_m,
    status?.mavlink?.connected,
    status?.mavlink?.latitude_deg,
    status?.mavlink?.longitude_deg,
    status?.mavlink?.altitude_amsl_m,
    status?.mavlink?.relative_altitude_m,
    status?.mavlink?.heading_deg,
    status?.mavlink?.yaw_deg,
  ]);
  const waypointCount = missionItems.filter((item) => item.type === "waypoint").length;
  const compactInputClass = "w-full rounded-2xl border border-white/10 bg-zinc-950/75 px-3 py-2 text-sm text-zinc-100 outline-none transition focus:border-cyan-400/70";
  const droneOptions = useMemo(() => getDroneOptions(status), [status]);

  useEffect(() => {
    if (!droneOptions.some((option) => option.id === selectedDroneId)) {
      setSelectedDroneId(droneOptions[0]?.id ?? "1:1");
    }
  }, [droneOptions, selectedDroneId]);

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-zinc-950 text-zinc-100 [contain:layout_paint_style]">
      <MissionMap
        status={mapStatus}
        missionItems={missionItems}
        selectedIndex={selectedMissionIndex}
        waypointPlacementMode={waypointPlacementMode}
        flightTrack={flightTrack}
        onSelectItem={(index) => {
          setSelectedMissionIndex(index);
          setMissionPanelOpen(true);
        }}
        onUpdateWaypointFromMap={updateWaypointFromMap}
        onAppendWaypointFromMap={appendWaypointFromMap}
        onToggleWaypointPlacement={() => setWaypointPlacementMode((previous) => !previous)}
        onOpenThreeEditor={() => setThreeEditorOpen(true)}
        onClearFlightTrack={() => setFlightTrack([])}
      />

      <Suspense fallback={<ThreeEditorFallback />}>
        {threeEditorOpen ? (
          <ThreeWaypointEditor
            open={threeEditorOpen}
            missionItems={missionItems}
            selectedIndex={selectedMissionIndex}
            status={mapStatus}
            onSelectItem={(index) => {
              setSelectedMissionIndex(index);
              setMissionPanelOpen(true);
            }}
            onUpdateMissionItem={updateMissionItem}
            onClose={() => setThreeEditorOpen(false)}
          />
        ) : null}
      </Suspense>

      <div className="pointer-events-none absolute inset-0 z-30">
        <MissionPanel
          open={missionPanelOpen}
          busyAction={busyAction}
          missionName={missionName}
          setMissionName={setMissionName}
          defaults={defaults}
          setDefaults={setDefaults}
          missionItems={missionItems}
          waypointCount={waypointCount}
          selectedMissionIndex={selectedMissionIndex}
          waypointPlacementMode={waypointPlacementMode}
          dragOverIndex={dragOverIndex}
          draggedIndex={draggedIndex}
          compactInputClass={compactInputClass}
          livePositionForStatus={livePositionForStatus}
          onClose={() => setMissionPanelOpen((previous) => !previous)}
          onToggleWaypointPlacement={() => setWaypointPlacementMode((previous) => !previous)}
          onSave={() => runAction("save", () => request("/api/mission", { method: "POST", body: JSON.stringify(payload) }), "Mission saved")}
          onActivate={() => runAction("activate", () => request("/api/activate", { method: "POST", body: JSON.stringify({ activate: true }) }), "Activate sent")}
          onRun={() => runAction("run", () => request("/api/mission/run", { method: "POST", body: JSON.stringify(payload) }), "Save + run sent")}
          onAppendItem={appendMissionItem}
          onAppendWaypointFromMap={appendWaypointFromMap}
          onUpdateMissionItem={updateMissionItem}
          onRemoveMissionItem={removeMissionItem}
          onApplyLivePosition={applyLivePosition}
          onSelectMissionIndex={setSelectedMissionIndex}
          onItemDragStart={handleItemDragStart}
          onItemDragOver={handleItemDragOver}
          onItemDrop={handleItemDrop}
          onItemDragEnd={handleItemDragEnd}
          missionRuntime={status.mission_runtime ?? EMPTY_STATUS.mission_runtime}
        />

        <DroneStatusPanel
          open={dronePanelOpen}
          loading={loading}
          status={status}
          drone={drone}
          droneOptions={droneOptions}
          selectedDroneId={selectedDroneId}
          setSelectedDroneId={setSelectedDroneId}
          livePositionForStatus={livePositionForStatus}
          logs={logs}
          onClose={() => setDronePanelOpen((previous) => !previous)}
        />
      </div>
    </div>
  );
}
