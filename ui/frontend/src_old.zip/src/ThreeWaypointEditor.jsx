import { useEffect, useRef, useState } from "react";
import * as THREE from "three";

const DEFAULT_MAP_CENTER = { latitude_deg: 10.823099, longitude_deg: 106.629662 };
const MAP_COORDINATE_ITEM_TYPES = new Set(["waypoint", "hold", "land"]);

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function hasValidCoordinate(latitude, longitude) {
  return Number.isFinite(Number(latitude)) && Number.isFinite(Number(longitude));
}

function itemCanUseMapCoordinate(item) {
  return MAP_COORDINATE_ITEM_TYPES.has(item?.type);
}

function findFirstMissionCoordinate(items, livePosition) {
  const firstItem = items.find((item) => hasValidCoordinate(item.latitude_deg, item.longitude_deg));
  if (firstItem) {
    return {
      latitude_deg: Number(firstItem.latitude_deg),
      longitude_deg: Number(firstItem.longitude_deg),
    };
  }
  if (hasValidCoordinate(livePosition?.latitude_deg, livePosition?.longitude_deg)) {
    return {
      latitude_deg: Number(livePosition.latitude_deg),
      longitude_deg: Number(livePosition.longitude_deg),
    };
  }
  return null;
}

function getMissionMarkerCoordinate(item, index, items, livePosition) {
  if (item.type === "rtl") {
    if (hasValidCoordinate(livePosition?.latitude_deg, livePosition?.longitude_deg)) {
      return {
        latitude_deg: Number(livePosition.latitude_deg),
        longitude_deg: Number(livePosition.longitude_deg),
        fromFallback: true,
        fromDrone: true,
      };
    }
    const homeCoordinate = findFirstMissionCoordinate(items, null);
    return homeCoordinate ? { ...homeCoordinate, fromFallback: true } : null;
  }

  if (hasValidCoordinate(item.latitude_deg, item.longitude_deg)) {
    return {
      latitude_deg: Number(item.latitude_deg),
      longitude_deg: Number(item.longitude_deg),
      fromFallback: false,
    };
  }

  if (itemCanUseMapCoordinate(item)) {
    const previousItem = items
      .slice(0, index)
      .reverse()
      .find((candidate) => hasValidCoordinate(candidate.latitude_deg, candidate.longitude_deg));
    if (previousItem) {
      return {
        latitude_deg: Number(previousItem.latitude_deg),
        longitude_deg: Number(previousItem.longitude_deg),
        fromFallback: true,
      };
    }
  }
  return null;
}

function getLivePosition(status) {
  const mavlink = status?.mavlink ?? {};
  if (mavlink.connected && hasValidCoordinate(mavlink.latitude_deg, mavlink.longitude_deg)) {
    return {
      latitude_deg: mavlink.latitude_deg,
      longitude_deg: mavlink.longitude_deg,
      altitude_amsl_m: mavlink.altitude_amsl_m,
      relative_altitude_m: mavlink.relative_altitude_m,
      source: "MAVLink",
    };
  }
  const rosPosition = status?.vehicle?.position ?? {};
  if (hasValidCoordinate(rosPosition.latitude_deg, rosPosition.longitude_deg)) {
    return { ...rosPosition, relative_altitude_m: null, source: "ROS 2" };
  }
  return { latitude_deg: null, longitude_deg: null, altitude_amsl_m: null, relative_altitude_m: null, source: "none" };
}

function getDroneTelemetry(status) {
  const mavlink = status?.mavlink ?? {};
  return { headingDeg: mavlink.heading_deg ?? mavlink.yaw_deg ?? null };
}

function getVisualAltitudeM(item, livePosition) {
  if (Number.isFinite(Number(item?.altitude_m))) {
    return Math.max(0, Number(item.altitude_m));
  }
  if (Number.isFinite(Number(livePosition?.relative_altitude_m))) {
    return Math.max(0, Number(livePosition.relative_altitude_m));
  }
  return 0;
}

function formatAltitudeLabel(value) {
  if (!Number.isFinite(Number(value))) {
    return "-- m";
  }
  const numeric = Number(value);
  if (Math.abs(numeric) >= 100) {
    return `${numeric.toFixed(0)} m`;
  }
  return `${numeric.toFixed(1)} m`;
}

function getTakeoffAltitude(missionItems, status) {
  const takeoffItem = Array.isArray(missionItems)
    ? missionItems.find((item) => item.type === "takeoff" && Number.isFinite(Number(item.altitude_m)))
    : null;
  if (takeoffItem) {
    return Number(takeoffItem.altitude_m);
  }
  const livePosition = getLivePosition(status ?? {});
  if (Number.isFinite(Number(livePosition.relative_altitude_m)) && Number(livePosition.relative_altitude_m) > 0.5) {
    return Number(livePosition.relative_altitude_m);
  }
  return 20;
}

function Icon({ name, className = "" }) {
  return <span className={`material-symbols-rounded ${className}`}>{name}</span>;
}

function MiniIconButton({ icon, label, onClick, disabled = false }) {
  return (
    <button
      type="button"
      title={label}
      disabled={disabled}
      onPointerDown={(event) => event.stopPropagation()}
      onClick={(event) => {
        event.stopPropagation();
        onClick?.(event);
      }}
      className="grid h-11 w-11 place-items-center rounded-2xl border border-white/10 bg-zinc-950/80 text-zinc-100 shadow-lg transition hover:bg-white/15 disabled:cursor-not-allowed disabled:opacity-40"
    >
      <Icon name={icon} className="text-[22px]" />
    </button>
  );
}

function getBaseCoordinateForScene(missionItems, livePosition) {
  const firstMissionCoordinate = missionItems.find((item) => hasValidCoordinate(item.latitude_deg, item.longitude_deg));
  if (firstMissionCoordinate) {
    return {
      latitude_deg: Number(firstMissionCoordinate.latitude_deg),
      longitude_deg: Number(firstMissionCoordinate.longitude_deg),
    };
  }

  if (hasValidCoordinate(livePosition.latitude_deg, livePosition.longitude_deg)) {
    return {
      latitude_deg: Number(livePosition.latitude_deg),
      longitude_deg: Number(livePosition.longitude_deg),
    };
  }

  return DEFAULT_MAP_CENTER;
}

function coordinateToSceneMeters(coordinate, baseCoordinate) {
  const baseLatitudeRad = (Number(baseCoordinate.latitude_deg) * Math.PI) / 180;
  const metersPerDegLat = 111_320;
  const metersPerDegLon = Math.max(1, 111_320 * Math.cos(baseLatitudeRad));
  return {
    x: (Number(coordinate.longitude_deg) - Number(baseCoordinate.longitude_deg)) * metersPerDegLon,
    z: -(Number(coordinate.latitude_deg) - Number(baseCoordinate.latitude_deg)) * metersPerDegLat,
  };
}

export default function ThreeWaypointEditor({
  open,
  missionItems,
  selectedIndex,
  status,
  onSelectItem,
  onUpdateMissionItem,
  onClose,
}) {
  const mountRef = useRef(null);
  const pipRef = useRef(null);
  const sceneRef = useRef(null);
  const cameraRef = useRef(null);
  const rendererRef = useRef(null);
  const objectsGroupRef = useRef(null);
  const frameRef = useRef(null);
  const resizeObserverRef = useRef(null);
  const pointerRef = useRef({ mode: "idle", lastX: 0, lastY: 0, selectedIndex: null });
  const pipPointerRef = useRef({ mode: "idle", startX: 0, startY: 0, startRect: null });
  const cameraControlRef = useRef({ azimuth: -2.25, elevation: 0.72, distance: 150 });
  const livePosition = getLivePosition(status);
  const drone = getDroneTelemetry(status);
  const selectedItem = Number.isInteger(selectedIndex) ? missionItems[selectedIndex] : null;
  const hasSelectedItem = Boolean(selectedItem);

  const [pipRect, setPipRect] = useState(() => {
    if (typeof window === "undefined") {
      return { x: 620, y: 520, width: 560, height: 350 };
    }

    try {
      const saved = JSON.parse(window.localStorage.getItem("adaptiveMissionThreePipRect") || "null");
      if (saved && Number.isFinite(saved.x) && Number.isFinite(saved.y) && Number.isFinite(saved.width) && Number.isFinite(saved.height)) {
        return {
          x: clamp(saved.x, 12, Math.max(12, window.innerWidth - 260)),
          y: clamp(saved.y, 72, Math.max(72, window.innerHeight - 180)),
          width: clamp(saved.width, 360, Math.min(820, window.innerWidth - 24)),
          height: clamp(saved.height, 260, Math.min(620, window.innerHeight - 96)),
        };
      }
    } catch {
      // Bỏ qua localStorage lỗi để UI vẫn mở được.
    }

    const width = Math.min(600, Math.max(420, window.innerWidth * 0.34));
    const height = Math.min(390, Math.max(300, window.innerHeight * 0.38));
    return {
      x: Math.max(84, window.innerWidth - width - 420),
      y: Math.max(120, window.innerHeight - height - 92),
      width,
      height,
    };
  });

  useEffect(() => {
    if (typeof window === "undefined") {
      return;
    }
    window.localStorage.setItem("adaptiveMissionThreePipRect", JSON.stringify(pipRect));
  }, [pipRect]);

  function fitPipRectToViewport(rect) {
    if (typeof window === "undefined") {
      return rect;
    }
    const width = clamp(rect.width, 360, Math.max(360, window.innerWidth - 24));
    const height = clamp(rect.height, 260, Math.max(260, window.innerHeight - 88));
    return {
      width,
      height,
      x: clamp(rect.x, 12, Math.max(12, window.innerWidth - width - 12)),
      y: clamp(rect.y, 72, Math.max(72, window.innerHeight - height - 12)),
    };
  }

  useEffect(() => {
    function handleViewportResize() {
      setPipRect((current) => fitPipRectToViewport(current));
    }

    window.addEventListener("resize", handleViewportResize);
    return () => window.removeEventListener("resize", handleViewportResize);
  }, []);

  function renderThreeFrame() {
    if (rendererRef.current && sceneRef.current && cameraRef.current) {
      rendererRef.current.render(sceneRef.current, cameraRef.current);
    }
  }

  function updateCameraView() {
    const camera = cameraRef.current;
    if (!camera) {
      return;
    }

    const control = cameraControlRef.current;
    const elevation = clamp(control.elevation, 0.18, 1.35);
    const distance = clamp(control.distance, 32, 420);
    control.elevation = elevation;
    control.distance = distance;

    const horizontalRadius = Math.cos(elevation) * distance;
    camera.position.set(
      Math.cos(control.azimuth) * horizontalRadius,
      Math.sin(elevation) * distance,
      Math.sin(control.azimuth) * horizontalRadius,
    );
    camera.lookAt(0, 0, 0);
    renderThreeFrame();
  }

  function resizeThreeRenderer() {
    if (!mountRef.current || !rendererRef.current || !cameraRef.current) {
      return;
    }

    const nextWidth = Math.max(280, mountRef.current.clientWidth);
    const nextHeight = Math.max(180, mountRef.current.clientHeight);
    cameraRef.current.aspect = nextWidth / nextHeight;
    cameraRef.current.updateProjectionMatrix();
    rendererRef.current.setSize(nextWidth, nextHeight);
    renderThreeFrame();
  }

  function zoomThreeCamera(delta) {
    cameraControlRef.current.distance = clamp(cameraControlRef.current.distance + delta, 32, 420);
    updateCameraView();
  }

  function resetThreeCamera() {
    cameraControlRef.current = { azimuth: -2.25, elevation: 0.72, distance: 150 };
    updateCameraView();
  }

  useEffect(() => {
    if (!open || !mountRef.current) {
      return undefined;
    }

    const mount = mountRef.current;
    const width = Math.max(280, mount.clientWidth);
    const height = Math.max(180, mount.clientHeight);
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x09090b);
    scene.fog = new THREE.Fog(0x09090b, 180, 560);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1200);
    const renderer = new THREE.WebGLRenderer({ antialias: false, alpha: false, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.35));
    renderer.setSize(width, height);
    mount.innerHTML = "";
    mount.appendChild(renderer.domElement);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.72);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1.25);
    directionalLight.position.set(60, 110, 80);
    scene.add(ambientLight, directionalLight);

    const grid = new THREE.GridHelper(220, 22, 0x22d3ee, 0x334155);
    grid.material.transparent = true;
    grid.material.opacity = 0.36;
    scene.add(grid);

    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(220, 220),
      new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.9, metalness: 0.0, transparent: true, opacity: 0.58 }),
    );
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.02;
    scene.add(ground);

    const objectsGroup = new THREE.Group();
    scene.add(objectsGroup);

    sceneRef.current = scene;
    cameraRef.current = camera;
    rendererRef.current = renderer;
    objectsGroupRef.current = objectsGroup;
    updateCameraView();

    renderThreeFrame();

    if (typeof ResizeObserver !== "undefined") {
      resizeObserverRef.current = new ResizeObserver(() => resizeThreeRenderer());
      resizeObserverRef.current.observe(mount);
    }

    return () => {
      if (resizeObserverRef.current) {
        resizeObserverRef.current.disconnect();
        resizeObserverRef.current = null;
      }
      renderer.dispose();
      mount.innerHTML = "";
      sceneRef.current = null;
      cameraRef.current = null;
      rendererRef.current = null;
      objectsGroupRef.current = null;
    };
  }, [open]);

  useEffect(() => {
    resizeThreeRenderer();
  }, [pipRect.width, pipRect.height]);

  useEffect(() => {
    if (!open || !objectsGroupRef.current) {
      return;
    }

    const group = objectsGroupRef.current;
    group.clear();
    const baseCoordinate = getBaseCoordinateForScene(missionItems, livePosition);
    const validMarkers = [];
    let waypointOrder = 0;

    const colorByType = {
      takeoff: 0x34d399,
      waypoint: 0x22d3ee,
      hold: 0xfacc15,
      land: 0xa78bfa,
      rtl: 0xfb7185,
    };

    missionItems.forEach((item, index) => {
      if (item.type === "waypoint") {
        waypointOrder += 1;
      }
      const coordinate = getMissionMarkerCoordinate(item, index, missionItems, livePosition);
      if (!coordinate || !hasValidCoordinate(coordinate.latitude_deg, coordinate.longitude_deg)) {
        return;
      }
      const local = coordinateToSceneMeters(coordinate, baseCoordinate);
      const altitudeM = getVisualAltitudeM(item, livePosition);
      const color = colorByType[item.type] ?? 0x22d3ee;
      const geometry = item.type === "hold"
        ? new THREE.SphereGeometry(3.5, 12, 8)
        : item.type === "rtl"
          ? new THREE.OctahedronGeometry(4.2)
          : new THREE.BoxGeometry(6.2, 6.2, 6.2);
      const material = new THREE.MeshStandardMaterial({ color, roughness: 0.38, metalness: 0.15, emissive: color, emissiveIntensity: selectedIndex === index ? 0.22 : 0.04 });
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(local.x, Math.max(1.5, altitudeM), local.z);
      mesh.userData = { type: "mission", index };
      mesh.name = `${item.type}-${index}`;
      group.add(mesh);

      const towerGeometry = new THREE.CylinderGeometry(0.42, 0.42, Math.max(1, altitudeM), 6);
      const towerMaterial = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.38 });
      const tower = new THREE.Mesh(towerGeometry, towerMaterial);
      tower.position.set(local.x, Math.max(0.5, altitudeM / 2), local.z);
      group.add(tower);

      validMarkers.push({ x: local.x, y: Math.max(1.5, altitudeM), z: local.z, type: item.type, index, waypointOrder });
    });

    if (validMarkers.length > 1) {
      const points = validMarkers.map((marker) => new THREE.Vector3(marker.x, marker.y, marker.z));
      const lineGeometry = new THREE.BufferGeometry().setFromPoints(points);
      const lineMaterial = new THREE.LineBasicMaterial({ color: 0x67e8f9, linewidth: 2, transparent: true, opacity: 0.9 });
      group.add(new THREE.Line(lineGeometry, lineMaterial));
    }

    if (hasValidCoordinate(livePosition.latitude_deg, livePosition.longitude_deg)) {
      const local = coordinateToSceneMeters(livePosition, baseCoordinate);
      const altitudeM = Math.max(1.5, Number(livePosition.relative_altitude_m) || 0);
      const droneDot = new THREE.Mesh(
        new THREE.SphereGeometry(3.2, 12, 8),
        new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.18, metalness: 0.25, emissive: 0x10b981, emissiveIntensity: 0.42 }),
      );
      droneDot.position.set(local.x, altitudeM, local.z);
      droneDot.name = "drone-dot";
      group.add(droneDot);

      const dotHalo = new THREE.Mesh(
        new THREE.SphereGeometry(5.4, 12, 8),
        new THREE.MeshBasicMaterial({ color: 0x10b981, transparent: true, opacity: 0.16 }),
      );
      dotHalo.position.copy(droneDot.position);
      group.add(dotHalo);
    }

    renderThreeFrame();
  }, [open, missionItems, selectedIndex, livePosition.latitude_deg, livePosition.longitude_deg, livePosition.relative_altitude_m, drone.headingDeg]);

  function handlePipPointerDown(mode, event) {
    event.stopPropagation();
    const nextMode = mode === "resize" ? "resize" : "drag";
    pipPointerRef.current = {
      mode: nextMode,
      startX: event.clientX,
      startY: event.clientY,
      startRect: { ...pipRect },
    };
    pipRef.current?.setPointerCapture?.(event.pointerId);
  }

  function handlePipPointerMove(event) {
    const pointer = pipPointerRef.current;
    if (pointer.mode === "idle" || !pointer.startRect) {
      return;
    }

    event.stopPropagation();
    const dx = event.clientX - pointer.startX;
    const dy = event.clientY - pointer.startY;

    if (pointer.mode === "drag") {
      setPipRect(fitPipRectToViewport({
        ...pointer.startRect,
        x: pointer.startRect.x + dx,
        y: pointer.startRect.y + dy,
      }));
      return;
    }

    if (pointer.mode === "resize") {
      setPipRect(fitPipRectToViewport({
        ...pointer.startRect,
        width: pointer.startRect.width + dx,
        height: pointer.startRect.height + dy,
      }));
    }
  }

  function handlePipPointerUp(event) {
    if (pipPointerRef.current.mode !== "idle") {
      event.stopPropagation();
    }
    pipPointerRef.current = { mode: "idle", startX: 0, startY: 0, startRect: null };
  }

  function handlePointerDown(event) {
    if (!rendererRef.current || !cameraRef.current || !sceneRef.current) {
      return;
    }

    const rect = rendererRef.current.domElement.getBoundingClientRect();
    const mouse = new THREE.Vector2(
      ((event.clientX - rect.left) / rect.width) * 2 - 1,
      -(((event.clientY - rect.top) / rect.height) * 2 - 1),
    );
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, cameraRef.current);
    const hits = raycaster.intersectObjects(objectsGroupRef.current?.children ?? [], true);
    const markerHit = hits.find((hit) => Number.isInteger(hit.object.userData?.index));

    if (markerHit) {
      const index = markerHit.object.userData.index;
      pointerRef.current = { mode: "altitude", lastX: event.clientX, lastY: event.clientY, selectedIndex: index };
      onSelectItem(index);
      event.currentTarget.setPointerCapture(event.pointerId);
      return;
    }

    pointerRef.current = { mode: "orbit", lastX: event.clientX, lastY: event.clientY, selectedIndex: null };
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function handlePointerMove(event) {
    const pointer = pointerRef.current;
    if (pointer.mode === "idle") {
      return;
    }

    const dx = event.clientX - pointer.lastX;
    const dy = event.clientY - pointer.lastY;
    pointer.lastX = event.clientX;
    pointer.lastY = event.clientY;

    if (pointer.mode === "altitude" && Number.isInteger(pointer.selectedIndex)) {
      const item = missionItems[pointer.selectedIndex];
      if (itemCanUseMapCoordinate(item)) {
        const currentAlt = Number.isFinite(Number(item.altitude_m)) ? Number(item.altitude_m) : getTakeoffAltitude(missionItems, status);
        const nextAlt = clamp(currentAlt - dy * 0.08, 0, 500);
        onUpdateMissionItem(pointer.selectedIndex, "altitude_m", Number(nextAlt.toFixed(2)));
      }
      return;
    }

    if (pointer.mode === "orbit") {
      cameraControlRef.current.azimuth += dx * 0.007;
      cameraControlRef.current.elevation = clamp(cameraControlRef.current.elevation + dy * 0.005, 0.18, 1.35);
      updateCameraView();
    }
  }

  function handlePointerUp() {
    pointerRef.current = { mode: "idle", lastX: 0, lastY: 0, selectedIndex: null };
  }

  function handleWheel(event) {
    event.preventDefault();
    event.stopPropagation();
    zoomThreeCamera(event.deltaY * 0.12);
  }

  function adjustSelectedAltitude(deltaM) {
    if (!selectedItem || !itemCanUseMapCoordinate(selectedItem)) {
      return;
    }
    const currentAlt = Number.isFinite(Number(selectedItem.altitude_m)) ? Number(selectedItem.altitude_m) : getTakeoffAltitude(missionItems, status);
    onUpdateMissionItem(selectedIndex, "altitude_m", Number(clamp(currentAlt + deltaM, 0, 500).toFixed(2)));
  }

  if (!open) {
    return null;
  }

  return (
    <section
      ref={pipRef}
      onPointerMove={handlePipPointerMove}
      onPointerUp={handlePipPointerUp}
      onPointerCancel={handlePipPointerUp}
      className="pointer-events-auto absolute z-[60] flex min-h-[260px] min-w-[360px] flex-col overflow-hidden rounded-[30px] border border-cyan-300/25 bg-zinc-950/92 shadow-[0_28px_90px_rgba(0,0,0,0.62)] backdrop-blur-xl"
      style={{ left: `${pipRect.x}px`, top: `${pipRect.y}px`, width: `${pipRect.width}px`, height: `${pipRect.height}px` }}
    >
      <header
        onPointerDown={(event) => handlePipPointerDown("drag", event)}
        className="flex cursor-move touch-none items-center justify-between gap-3 border-b border-white/10 px-4 py-3"
      >
        <div className="flex min-w-0 items-center gap-3">
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-cyan-400/12 text-cyan-100">
            <Icon name="deployed_code" className="text-[25px]" />
          </div>
          <div className="min-w-0">
            <h3 className="truncate text-sm font-black text-zinc-50">3D Waypoint Editor</h3>
            <p className="truncate text-[11px] text-zinc-500">Kéo cửa sổ · kéo nền để xoay · cuộn chuột để zoom</p>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <MiniIconButton icon="zoom_in" label="Zoom in" onClick={() => zoomThreeCamera(-18)} />
          <MiniIconButton icon="zoom_out" label="Zoom out" onClick={() => zoomThreeCamera(18)} />
          <MiniIconButton icon="center_focus_strong" label="Reset camera" onClick={resetThreeCamera} />
          <MiniIconButton icon="close" label="Close 3D editor" onClick={onClose} />
        </div>
      </header>

      <div className="grid min-h-0 flex-1 grid-cols-[1fr_148px]">
        <div
          ref={mountRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onWheel={handleWheel}
          className="relative min-h-0 cursor-grab overflow-hidden active:cursor-grabbing"
        />
        <aside className="min-h-0 overflow-y-auto border-l border-white/10 bg-white/[0.035] p-3">
          <div className="rounded-2xl border border-white/10 bg-zinc-950/55 p-3">
            <p className="text-[10px] font-black uppercase tracking-[0.14em] text-zinc-500">Selected</p>
            <p className="mt-1 truncate text-sm font-black text-zinc-100">{selectedItem?.name ?? "None"}</p>
            <p className="mt-1 text-[11px] text-zinc-500">#{hasSelectedItem ? selectedIndex + 1 : "--"} · {selectedItem?.type ?? "--"}</p>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-2">
            <MiniIconButton icon="add" label="Altitude +1 m" onClick={() => adjustSelectedAltitude(1)} disabled={!itemCanUseMapCoordinate(selectedItem)} />
            <MiniIconButton icon="remove" label="Altitude -1 m" onClick={() => adjustSelectedAltitude(-1)} disabled={!itemCanUseMapCoordinate(selectedItem)} />
            <MiniIconButton icon="keyboard_double_arrow_up" label="Altitude +5 m" onClick={() => adjustSelectedAltitude(5)} disabled={!itemCanUseMapCoordinate(selectedItem)} />
            <MiniIconButton icon="keyboard_double_arrow_down" label="Altitude -5 m" onClick={() => adjustSelectedAltitude(-5)} disabled={!itemCanUseMapCoordinate(selectedItem)} />
          </div>

          <div className="mt-3 rounded-2xl border border-white/10 bg-zinc-950/55 p-3">
            <p className="text-[10px] font-black uppercase tracking-[0.14em] text-zinc-500">Altitude</p>
            <p className="mt-1 font-mono text-lg font-black text-cyan-100">{formatAltitudeLabel(selectedItem?.altitude_m)}</p>
            <p className="mt-2 text-[10px] leading-4 text-zinc-500">Chấm xanh là drone. Object mission có thể kéo lên/xuống để chỉnh cao độ.</p>
          </div>
        </aside>
      </div>

      <button
        type="button"
        title="Resize 3D window"
        onPointerDown={(event) => handlePipPointerDown("resize", event)}
        className="absolute bottom-2 right-2 z-10 h-7 w-7 cursor-nwse-resize rounded-xl border border-white/10 bg-white/10 text-zinc-300 hover:bg-white/20"
      >
        <Icon name="open_in_full" className="text-[17px] rotate-90" />
      </button>
    </section>
  );
}
